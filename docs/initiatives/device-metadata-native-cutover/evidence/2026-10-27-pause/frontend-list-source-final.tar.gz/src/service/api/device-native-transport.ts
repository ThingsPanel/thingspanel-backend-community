import type { components, operations } from './generated/device-metadata/types'
import {
  createMetadataNativeRequester,
  requireNativeStrongEtag,
  type MetadataNativeErrorBody
} from './metadata-native-http'

export type DeviceListQuery = NonNullable<operations['listDevices']['parameters']['query']>
export type DeviceStatisticsQuery = NonNullable<operations['getDeviceStatistics']['parameters']['query']>
export type DeviceStatistics = components['schemas']['DeviceStatistics']
export type DevicePage = components['schemas']['DevicePage']
export type Device = components['schemas']['Device']
export type DeviceTemplateBinding = components['schemas']['DeviceTemplateBinding']
export type DeviceTemplateBindingResponse = components['schemas']['DeviceTemplateBindingResponse']
export type CreateDevice = components['schemas']['CreateDevice']
export type UpdateDevice = components['schemas']['UpdateDevice']
export type DeviceNativeErrorBody = MetadataNativeErrorBody

export interface DeviceNativeOptions {
  fetch: typeof globalThis.fetch
  getToken: () => string | undefined | null
  getLanguage: () => string | undefined | null
}

export interface DeviceNativeClient {
  list(query: DeviceListQuery): Promise<DevicePage>
  statistics(query?: DeviceStatisticsQuery): Promise<DeviceStatistics>
  get(id: string): Promise<{ device: Device; etag: string }>
  readTemplateBinding(id: string): Promise<{ binding: DeviceTemplateBinding; etag: string }>
  create(body: CreateDevice, idempotencyKey: string): Promise<{ device: Device; etag?: string; location: string }>
  update(
    id: string,
    body: UpdateDevice,
    etag: string,
    idempotencyKey: string
  ): Promise<{ device: Device; etag: string }>
}

export class DeviceNativeError extends Error {
  constructor(
    readonly status: number,
    readonly body?: DeviceNativeErrorBody
  ) {
    super(body && 'detail' in body ? body.detail : body?.message || `Device service request failed (${status})`)
    this.name = 'DeviceNativeError'
  }

  get code(): string | undefined {
    return this.body?.code
  }
}

function queryString(query: DeviceListQuery): string {
  const params = new URLSearchParams()
  for (const [key, value] of Object.entries(query)) {
    if (value !== undefined) params.set(key, String(value))
  }
  return `?${params.toString()}`
}

function requireKey(key: string): string {
  if (!/^[A-Za-z0-9._:-]{8,128}$/.test(key)) throw new Error('Idempotency-Key must be 8 to 128 allowed characters')
  return key
}

export function createDeviceNativeClient(options: DeviceNativeOptions): DeviceNativeClient {
  const request = createMetadataNativeRequester({ ...options, resourceName: 'Device' })

  return {
    async statistics(query = {}) {
      const { data } = await request<DeviceStatistics, DeviceNativeError>(
        `/api/v2/device-statistics${queryString(query)}`,
        200,
        (status, body) => new DeviceNativeError(status, body),
        { method: 'GET' }
      )
      return data
    },
    async list(query) {
      const { data } = await request<DevicePage, DeviceNativeError>(
        `/api/v2/devices${queryString(query)}`,
        200,
        (status, body) => new DeviceNativeError(status, body),
        { method: 'GET' }
      )
      return data
    },
    async get(id) {
      const { data: device, response } = await request<Device, DeviceNativeError>(
        `/api/v2/devices/${encodeURIComponent(id)}`,
        200,
        (status, body) => new DeviceNativeError(status, body),
        { method: 'GET' }
      )
      return { device, etag: requireNativeStrongEtag(response.headers.get('ETag'), 'Device') }
    },
    async readTemplateBinding(id) {
      const { data: binding, response } = await request<DeviceTemplateBindingResponse['data'], DeviceNativeError>(
        `/api/v2/devices/${encodeURIComponent(id)}/template-binding`,
        200,
        (status, body) => new DeviceNativeError(status, body),
        { method: 'GET', redirect: 'manual' }
      )
      return { binding, etag: requireNativeStrongEtag(response.headers.get('ETag'), 'Device template binding') }
    },
    async create(body, idempotencyKey) {
      const headers = new Headers({ 'Idempotency-Key': requireKey(idempotencyKey) })
      const { data: device, response } = await request<Device, DeviceNativeError>(
        '/api/v2/devices',
        201,
        (status, errorBody) => new DeviceNativeError(status, errorBody),
        { method: 'POST', headers, body: JSON.stringify(body) }
      )
      const location = response.headers.get('Location')
      if (!location) throw new Error('Device create response is missing Location')
      const etag = response.headers.get('ETag')
      return { device, ...(etag ? { etag: requireNativeStrongEtag(etag, 'Device') } : {}), location }
    },
    async update(id, body, etag, idempotencyKey) {
      const headers = new Headers({
        'If-Match': requireNativeStrongEtag(etag, 'Device'),
        'Idempotency-Key': requireKey(idempotencyKey)
      })
      const { data: device, response } = await request<Device, DeviceNativeError>(
        `/api/v2/devices/${encodeURIComponent(id)}`,
        200,
        (status, errorBody) => new DeviceNativeError(status, errorBody),
        { method: 'PATCH', headers, body: JSON.stringify(body) }
      )
      return { device, etag: requireNativeStrongEtag(response.headers.get('ETag'), 'Device') }
    }
  }
}
