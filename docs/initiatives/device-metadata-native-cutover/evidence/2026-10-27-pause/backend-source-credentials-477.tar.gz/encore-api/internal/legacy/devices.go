package legacy

import (
	"context"
	"encoding/json"
	"net/url"
	"strconv"
)

func (c *Client) GetDeviceDetail(ctx context.Context, deviceID string) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "GET", "/api/v1/device/detail/"+url.PathEscape(deviceID), token, nil)
}

func (c *Client) ListDevices(ctx context.Context, page, pageSize int) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	q := url.Values{}
	q.Set("page", itoa(page))
	q.Set("page_size", itoa(pageSize))
	return c.doRaw(ctx, "GET", "/api/v1/device?"+q.Encode(), token, nil)
}

func (c *Client) ListDevicesSimple(ctx context.Context) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "GET", "/api/v1/device/list", token, nil)
}

func (c *Client) GetDeviceOnlineStatus(ctx context.Context, deviceID string) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "GET", "/api/v1/device/online/status/"+url.PathEscape(deviceID), token, nil)
}

func (c *Client) CreateDevice(ctx context.Context, body any) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "POST", "/api/v1/device", token, body)
}

func (c *Client) UpdateDevice(ctx context.Context, body any) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "PUT", "/api/v1/device", token, body)
}

func (c *Client) DeleteDevice(ctx context.Context, deviceID string) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "DELETE", "/api/v1/device/"+url.PathEscape(deviceID), token, nil)
}

func (c *Client) ActivateDevice(ctx context.Context, body any) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "PUT", "/api/v1/device/active", token, body)
}

func (c *Client) CheckDeviceNumber(ctx context.Context, deviceNumber string) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "GET", "/api/v1/device/check/"+url.PathEscape(deviceNumber), token, nil)
}

func (c *Client) DeviceSelector(ctx context.Context, page, pageSize int, search string) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	q := url.Values{}
	q.Set("page", itoa(page))
	q.Set("page_size", itoa(pageSize))
	q.Set("search", search)
	return c.doRaw(ctx, "GET", "/api/v1/device/selector?"+q.Encode(), token, nil)
}

func (c *Client) UpdateDeviceVoucher(ctx context.Context, body any) (json.RawMessage, error) {
	token, err := c.Login(ctx)
	if err != nil {
		return nil, err
	}
	return c.doRaw(ctx, "POST", "/api/v1/device/update/voucher", token, body)
}

func itoa(v int) string {
	return strconv.Itoa(v)
}
