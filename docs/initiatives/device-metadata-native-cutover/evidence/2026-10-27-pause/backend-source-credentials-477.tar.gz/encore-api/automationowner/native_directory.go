package automationowner

import (
	"context"
	"encoding/json"
	"fmt"
	"sort"
	"strings"

	"encore.app/automationowner/ports"
	"encore.app/devicemetadata"
	"encore.app/internal/tenantidentity"
	"encore.dev/beta/errs"
)

type nativeDirectoryResolver func(context.Context, *devicemetadata.ResolveAutomationDirectoryRequest) (*devicemetadata.ResolveAutomationDirectoryResponse, error)
type nativeScopeResolver func(context.Context, *devicemetadata.ValidateAutomationScopeRequest) (*devicemetadata.ValidateAutomationScopeResponse, error)

type nativeDirectory struct {
	resolve      nativeDirectoryResolver
	resolveScope nativeScopeResolver
}

// newNativeAutomationDirectory creates the owner-to-owner private RPC adapter.
func newNativeAutomationDirectory() ports.Directory {
	return &nativeDirectory{
		resolve: func(ctx context.Context, req *devicemetadata.ResolveAutomationDirectoryRequest) (*devicemetadata.ResolveAutomationDirectoryResponse, error) {
			return devicemetadata.ResolveAutomationDirectory(ctx, req)
		},
		resolveScope: func(ctx context.Context, req *devicemetadata.ValidateAutomationScopeRequest) (*devicemetadata.ValidateAutomationScopeResponse, error) {
			return devicemetadata.ValidateAutomationScope(ctx, req)
		},
	}
}

func (d *nativeDirectory) ValidateScope(ctx context.Context, rawTenant, scopeType, rawScopeID string) error {
	if d == nil || d.resolveScope == nil {
		return &errs.Error{Code: errs.Unavailable, Message: "native automation scope validator is unavailable"}
	}
	tenantID := tenantidentity.NormalizePrincipalID(rawTenant)
	scopeID := rawScopeID
	if scopeType != "device" && scopeType != "device_config" {
		return &errs.Error{Code: errs.InvalidArgument, Message: "scope type must be device or device_config"}
	}
	resp, err := d.resolveScope(ctx, &devicemetadata.ValidateAutomationScopeRequest{TenantID: tenantID, ScopeType: scopeType, ScopeID: scopeID})
	if err != nil {
		if code := errs.Code(err); code == errs.NotFound || code == errs.PermissionDenied || code == errs.InvalidArgument {
			return err
		}
		return errs.WrapCode(err, errs.Unavailable, "native automation scope validation is unavailable")
	}
	if resp == nil || resp.ID != scopeID || resp.ScopeType != scopeType {
		return &errs.Error{Code: errs.Unavailable, Message: "native automation scope validation returned an invalid result"}
	}
	return nil
}

func (d *nativeDirectory) ByIDs(ctx context.Context, tenantID string, ids []string) ([]ports.Device, error) {
	return d.query(ctx, tenantID, "ids", ids, nil, false, "")
}
func (d *nativeDirectory) ByDeviceConfig(ctx context.Context, tenantID string, ids []string) ([]ports.Device, error) {
	return d.query(ctx, tenantID, "templates", ids, nil, false, "")
}
func (d *nativeDirectory) ByLabels(ctx context.Context, tenantID string, labels []string, matchAll bool) ([]ports.Device, error) {
	return d.query(ctx, tenantID, "labels", nil, labels, matchAll, "")
}
func (d *nativeDirectory) ByType(ctx context.Context, tenantID, kind string) ([]ports.Device, error) {
	return d.query(ctx, tenantID, "kind", nil, nil, false, kind)
}

func (d *nativeDirectory) query(ctx context.Context, rawTenant, selector string, ids, labels []string, matchAll bool, kind string) ([]ports.Device, error) {
	if d == nil || d.resolve == nil {
		return nil, &errs.Error{Code: errs.Unavailable, Message: "native device directory is unavailable"}
	}
	tenantID := tenantidentity.NormalizePrincipalID(rawTenant)
	resp, err := d.resolve(ctx, &devicemetadata.ResolveAutomationDirectoryRequest{TenantID: tenantID, Selector: selector, IDs: ids, Labels: labels, MatchAll: matchAll, DeviceKind: kind})
	if err != nil {
		return nil, errs.WrapCode(err, errs.Unavailable, "native device directory is unavailable")
	}
	if resp == nil || !resp.Complete {
		return nil, &errs.Error{Code: errs.Unavailable, Message: "native device directory did not return a complete result"}
	}
	out := make([]ports.Device, 0, len(resp.Devices))
	for _, item := range resp.Devices {
		if tenantidentity.NormalizePrincipalID(item.TenantID) != tenantID {
			return nil, &errs.Error{Code: errs.Unavailable, Message: "native device directory returned a cross-tenant record"}
		}
		mappedType, ok := legacyDeviceType(item.DeviceKind)
		if !ok {
			return nil, &errs.Error{Code: errs.Unavailable, Message: "native device directory returned an unsupported device kind"}
		}
		configID := ""
		if item.TemplateID != nil {
			configID = *item.TemplateID
		}
		out = append(out, ports.Device{ID: item.ID, TenantID: tenantID, Name: item.Name, Label: displayNativeLabels(item.Labels), DeviceConfigID: configID, DeviceType: mappedType, Online: -1, Capabilities: nil})
	}
	return out, nil
}

func legacyDeviceType(kind string) (string, bool) {
	switch kind {
	case "standalone", "1":
		return "1", true
	case "gateway", "2":
		return "2", true
	case "subdevice", "3":
		return "3", true
	default:
		return "", false
	}
}

func displayNativeLabels(raw json.RawMessage) string {
	var labels map[string]any
	if json.Unmarshal(raw, &labels) != nil {
		return ""
	}
	pairs := make([]string, 0, len(labels))
	for key, value := range labels {
		pairs = append(pairs, fmt.Sprintf("%s=%v", key, value))
	}
	sort.Strings(pairs)
	return strings.Join(pairs, ",")
}
