package store

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"time"
)

// ScopeWrite commits the mutation and its response together. An unreadable
// receipt never authorizes a second mutation. Empty keys retain the old typed
// API's behavior; the native console always supplies a stable request_id.
func (s *Store) ScopeWrite(ctx context.Context, tenantID, actorID, key, operation string, payload any, apply func(*sql.Tx) ([]byte, error)) ([]byte, error) {
	canonical, err := json.Marshal(struct {
		Actor     string `json:"actor"`
		Operation string `json:"operation"`
		Payload   any    `json:"payload"`
	}{actorID, operation, payload})
	if err != nil {
		return nil, err
	}
	sum := sha256.Sum256(canonical)
	fingerprint := hex.EncodeToString(sum[:])
	tx, err := s.DB.BeginTx(ctx, nil)
	if err != nil {
		return nil, err
	}
	defer tx.Rollback()
	if key != "" {
		if _, err := tx.ExecContext(ctx, `SELECT pg_advisory_xact_lock(hashtextextended($1, 491207))`, tenantID+":"+key); err != nil {
			return nil, err
		}
		var stored, storedHash, endpoint string
		var created time.Time
		err := tx.QueryRowContext(ctx, `SELECT response::text,request_hash,endpoint,created_at FROM auto_requests WHERE tenant_id=$1 AND request_key=$2 FOR UPDATE`, tenantID, key).Scan(&stored, &storedHash, &endpoint, &created)
		if err == nil {
			if storedHash != fingerprint || endpoint != operation || time.Since(created) > 24*time.Hour {
				return nil, ErrConflict
			}
			if !json.Valid([]byte(stored)) {
				return nil, fmt.Errorf("invalid stored scope response")
			}
			if err := tx.Commit(); err != nil {
				return nil, err
			}
			return []byte(stored), nil
		}
		if !errors.Is(err, sql.ErrNoRows) {
			return nil, err
		}
	}
	response, err := apply(tx)
	if err != nil {
		return nil, err
	}
	if !json.Valid(response) {
		return nil, fmt.Errorf("invalid scope mutation response")
	}
	if key != "" {
		if _, err := tx.ExecContext(ctx, `INSERT INTO auto_requests(tenant_id,request_key,endpoint,response,request_hash) VALUES($1,$2,$3,$4::jsonb,$5)`, tenantID, key, operation, response, fingerprint); err != nil {
			return nil, err
		}
	}
	if err := tx.Commit(); err != nil {
		return nil, err
	}
	return response, nil
}

// UpsertScopeBindingTx returns the actual stable row, including its original
// ID when reattaching an existing scope. It never returns an invented ID.
func (s *Store) UpsertScopeBindingTx(ctx context.Context, tx *sql.Tx, b *Binding) (*Binding, error) {
	params, err := json.Marshal(b.Params)
	if err != nil {
		return nil, err
	}
	return scanBinding(tx.QueryRowContext(ctx, `INSERT INTO auto_bindings(id,binding_key,tenant_id,rule_id,revision,source,device_id,device_config_id,template_id,params,enabled)
	VALUES($1,$2,$3,$4,$5,$6,NULLIF($7,''),NULLIF($8,''),NULLIF($9,''),$10::jsonb,true)
	ON CONFLICT(binding_key) DO UPDATE SET revision=EXCLUDED.revision,params=EXCLUDED.params,enabled=true,source=EXCLUDED.source,detached_at=NULL,updated_at=now()
	RETURNING `+bindingColumns, b.ID, b.BindingKey, b.TenantID, b.RuleID, b.Revision, b.Source, b.DeviceID, b.DeviceConfigID, b.TemplateID, params))
}

func (s *Store) DetachScopeBindingTx(ctx context.Context, tx *sql.Tx, tenantID, id string) (*Binding, error) {
	b, err := scanBinding(tx.QueryRowContext(ctx, `UPDATE auto_bindings SET enabled=false,detached_at=coalesce(detached_at,now()),updated_at=CASE WHEN enabled THEN now() ELSE updated_at END WHERE tenant_id=$1 AND id=$2 RETURNING `+bindingColumns, tenantID, id))
	if errors.Is(err, sql.ErrNoRows) {
		return nil, ErrNotFound
	}
	return b, err
}

// AcknowledgeEpisodeTx locks the episode and records acknowledgement and its
// transition atomically. Repeating acknowledgement does not change the actor,
// timestamp, sequence or history, and never clears the active alarm.
func (s *Store) AcknowledgeEpisodeTx(ctx context.Context, tx *sql.Tx, tenantID, id, actor, transitionID string) (bool, error) {
	ep, err := scanEpisode(tx.QueryRowContext(ctx, `SELECT `+episodeColumns+` FROM alarm_episodes WHERE tenant_id=$1 AND id=$2 FOR UPDATE`, tenantID, id))
	if errors.Is(err, sql.ErrNoRows) {
		return false, ErrNotFound
	}
	if err != nil {
		return false, err
	}
	if ep.AckedAt != nil {
		return true, nil
	}
	if ep.State != "active" {
		return false, nil
	}
	var seq int64
	if err := tx.QueryRowContext(ctx, `SELECT nextval('auto_seq')`).Scan(&seq); err != nil {
		return false, err
	}
	if _, err := tx.ExecContext(ctx, `UPDATE alarm_episodes SET acked_at=now(),acked_by=$3,last_seq=GREATEST(last_seq,$4),updated_at=now() WHERE tenant_id=$1 AND id=$2`, tenantID, id, actor, seq); err != nil {
		return false, err
	}
	_, err = s.AddTransition(ctx, tx, &Transition{ID: transitionID, EpisodeID: id, TenantID: tenantID, Kind: "ack", Seq: seq, Revision: ep.Revision, Epoch: ep.Epoch, Evidence: map[string]any{"actor": actor, "state": "active"}})
	return err == nil, err
}
