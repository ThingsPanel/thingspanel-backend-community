package automationowner

import (
	"testing"

	"encore.app/automationowner/runtime"
	"encore.dev/beta/errs"
)

func TestNativeAlarmPaginationKeepsCompleteHistoryAndTenantFence(t *testing.T) {
	e := newEnv(t)
	nativeScopeAuth(t, e.tenant, "alarm-history-admin")
	s := &Service{rt: e.rt}
	prefix := "page-alarm-" + runtime.NewID() + "-"
	_, err := e.st.DB.ExecContext(e.ctx(), `INSERT INTO alarm_episodes(id,tenant_id,policy_id,policy_key,subject_id,dimension,state,revision,epoch,opened_at,last_seq)
	SELECT $1||lpad(g::text,3,'0'),$2,'page-policy','page-policy',$3,g::text,CASE WHEN g=251 THEN 'active' ELSE 'cleared' END,1,1,'2026-01-01T00:00:00Z',g FROM generate_series(1,251) AS g`, prefix, e.tenant, e.dev1)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _, _ = e.st.DB.ExecContext(e.ctx(), `DELETE FROM alarm_episodes WHERE tenant_id=$1`, e.tenant) })
	first, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, Limit: 200})
	if err != nil || first.Total != 251 || len(first.Alarms) != 200 || first.Offset != 0 || first.Limit != 200 {
		t.Fatalf("first=%+v err=%v", first, err)
	}
	second, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, Limit: 200, Offset: 200})
	if err != nil || second.Total != 251 || len(second.Alarms) != 51 {
		t.Fatalf("second=%+v err=%v", second, err)
	}
	seen := map[string]bool{}
	for _, page := range []*ListAlarmsResponse{first, second} {
		for _, ep := range page.Alarms {
			if seen[ep.ID] {
				t.Fatalf("duplicate across equal-time pages: %s", ep.ID)
			}
			seen[ep.ID] = true
		}
	}
	if len(seen) != 251 {
		t.Fatalf("history truncated: unique=%d", len(seen))
	}
	active, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, State: "active", Limit: 20})
	if err != nil || active.Total != 1 || len(active.Alarms) != 1 {
		t.Fatalf("active=%+v err=%v", active, err)
	}
	cleared, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, State: "cleared", Limit: 20, Offset: 240})
	if err != nil || cleared.Total != 250 || len(cleared.Alarms) != 10 {
		t.Fatalf("cleared=%+v err=%v", cleared, err)
	}
	empty, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, Limit: 20, Offset: 1000})
	if err != nil || empty.Total != 251 || len(empty.Alarms) != 0 {
		t.Fatalf("empty=%+v err=%v", empty, err)
	}
	for _, req := range []*ListAlarmsRequest{{Limit: 201}, {Offset: -1}, {State: "offline"}} {
		if _, err := s.ListAlarms(e.ctx(), req); errs.Code(err) != errs.InvalidArgument {
			t.Fatalf("invalid page %+v accepted: %v", req, err)
		}
	}
	// Another authenticated tenant sees none of this subject's history.
	nativeScopeAuth(t, "foreign-"+runtime.NewID(), "other-alarm-admin")
	foreign, err := s.ListAlarms(e.ctx(), &ListAlarmsRequest{SubjectID: e.dev1, Limit: 200})
	if err != nil || foreign.Total != 0 || len(foreign.Alarms) != 0 {
		t.Fatalf("cross-tenant history=%+v err=%v", foreign, err)
	}
}
