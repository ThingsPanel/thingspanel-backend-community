-- Number 14 is reserved for the separately developed A31 migration workflow.
-- Scope mutations reuse the owner's existing receipt table, with a request
-- fingerprint so a key cannot silently stand for a different operation/body.
ALTER TABLE auto_requests ADD COLUMN request_hash text NOT NULL DEFAULT '';
