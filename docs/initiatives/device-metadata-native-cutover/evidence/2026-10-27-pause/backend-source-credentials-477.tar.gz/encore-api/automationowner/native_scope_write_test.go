package automationowner

import (
	"context"
	"database/sql"
	"errors"
	"testing"

	"encore.app/automationowner/domain"
	"encore.app/automationowner/runtime"
	"encore.app/l1-access/authn"
	"encore.dev/beta/auth"
	"encore.dev/beta/errs"
	"encore.dev/et"
)

func nativeScopeAuth(t *testing.T, tenant, user string) {
	t.Helper()
	et.OverrideAuthInfo(auth.UID(user), &authn.Data{UserID: user, TenantID: tenant, Roles: []string{"TENANT_ADMIN"}})
	t.Cleanup(func() { et.OverrideAuthInfo("", nil) })
}

func TestNativeAutomationBindingRetriesKeepStableIdentityAndIntent(t *testing.T) {
	e := newEnv(t)
	nativeScopeAuth(t, e.tenant, "native-binding-admin")
	s := &Service{rt: e.rt}
	rule := e.createRule(paramRule(e, "30"))
	key := "attach-" + runtime.NewID()
	req := &AttachBindingRequest{RequestID: key, ScopeType: "device_config", ScopeID: "cfg-1", Params: map[string]string{"limit": "30"}}
	first, err := s.AttachBinding(e.ctx(), rule.ID, req)
	if err != nil {
		t.Fatal(err)
	}
	replayed, err := s.AttachBinding(e.ctx(), rule.ID, req)
	if err != nil || replayed.ID != first.ID {
		t.Fatalf("replay ID changed: first=%+v replay=%+v err=%v", first, replayed, err)
	}
	req.Params = map[string]string{"limit": "31"}
	if _, err := s.AttachBinding(e.ctx(), rule.ID, req); errs.Code(err) != errs.Aborted {
		t.Fatalf("same key with changed intent: %v", err)
	}
	rows, err := e.st.ListBindingsForRule(e.ctx(), e.tenant, rule.ID)
	if err != nil || len(rows) != 1 || rows[0].Params["limit"] != "30" {
		t.Fatalf("duplicate/changed binding: %+v err=%v", rows, err)
	}
	detachKey := "detach-" + runtime.NewID()
	detached, err := s.DetachScopeBinding(e.ctx(), first.ID, &DetachScopeBindingRequest{RequestID: detachKey})
	if err != nil || detached.Enabled || detached.DetachedAt == nil {
		t.Fatalf("detach=%+v err=%v", detached, err)
	}
	detachReplay, err := s.DetachScopeBinding(e.ctx(), first.ID, &DetachScopeBindingRequest{RequestID: detachKey})
	if err != nil || detachReplay.DetachedAt == nil || !detachReplay.DetachedAt.Equal(*detached.DetachedAt) {
		t.Fatalf("detach replay changed history: %+v err=%v", detachReplay, err)
	}
	reattached, err := s.AttachBinding(e.ctx(), rule.ID, &AttachBindingRequest{RequestID: "reattach-" + runtime.NewID(), ScopeType: "device_config", ScopeID: "cfg-1", Params: map[string]string{"limit": "35"}})
	if err != nil || reattached.ID != first.ID || !reattached.Enabled {
		t.Fatalf("reattach invented an ID: %+v err=%v", reattached, err)
	}
	// A late retry of the first request must replay its result, not revert a
	// subsequent deliberate change or reattach a detached scope again.
	req.Params = map[string]string{"limit": "30"}
	if _, err := s.AttachBinding(e.ctx(), rule.ID, req); err != nil {
		t.Fatal(err)
	}
	stored, err := e.st.GetBinding(e.ctx(), e.tenant, first.ID)
	if err != nil || stored.Params["limit"] != "35" {
		t.Fatalf("old retry overwrote newer intent: %+v err=%v", stored, err)
	}
}

func TestNativeAutomationAcknowledgementUsesTrustedActorAndIsAtomic(t *testing.T) {
	e := newEnv(t)
	nativeScopeAuth(t, e.tenant, "native-alarm-admin")
	s := &Service{rt: e.rt}
	policy := e.alarmPolicy(nil)
	e.ingest("native-ack-event-"+runtime.NewID(), e.dev1, "temperature", 35.0, "")
	ep := e.activeAlarm(policy.PolicyKey(), e.dev1)
	if ep == nil {
		t.Fatal("alarm fixture did not open")
	}
	key := "ack-" + runtime.NewID()
	response, err := s.AckAlarm(e.ctx(), ep.ID, &AckAlarmRequest{RequestID: key, Actor: "forged-actor"})
	if err != nil || !response.Acknowledged {
		t.Fatalf("ack=%+v err=%v", response, err)
	}
	before, err := e.st.GetEpisodeByID(e.ctx(), e.tenant, ep.ID)
	if err != nil || before.AckedBy != "native-alarm-admin" || before.AckedAt == nil || before.State != "active" {
		t.Fatalf("ack forged actor or cleared alarm: %+v err=%v", before, err)
	}
	if _, err := s.AckAlarm(e.ctx(), ep.ID, &AckAlarmRequest{RequestID: key}); err != nil {
		t.Fatal(err)
	}
	if _, err := s.AckAlarm(e.ctx(), ep.ID, &AckAlarmRequest{RequestID: "another-ack-" + runtime.NewID()}); err != nil {
		t.Fatal(err)
	}
	after, err := e.st.GetEpisodeByID(e.ctx(), e.tenant, ep.ID)
	if err != nil || !after.AckedAt.Equal(*before.AckedAt) || after.LastSeq != before.LastSeq {
		t.Fatalf("repeated acknowledgement changed history: %+v err=%v", after, err)
	}
	transitions, err := e.st.ListTransitions(e.ctx(), ep.ID)
	if err != nil {
		t.Fatal(err)
	}
	acks := 0
	for _, tr := range transitions {
		if tr.Kind == runtime.TransitionAck {
			acks++
		}
	}
	if acks != 1 {
		t.Fatalf("ack transition count=%d want 1", acks)
	}
	// A mutation error after updating the episode must roll back both facts.
	e2 := newEnv(t)
	policy2 := e2.alarmPolicy(nil)
	e2.ingest("native-rollback-event-"+runtime.NewID(), e2.dev1, "temperature", 35.0, "")
	ep2 := e2.activeAlarm(policy2.PolicyKey(), e2.dev1)
	if ep2 == nil {
		t.Fatal("rollback alarm fixture did not open")
	}
	rollbackKey := "ack-rollback-" + runtime.NewID()
	forced := errors.New("reject after mutation")
	_, err = e2.st.ScopeWrite(context.Background(), e2.tenant, "native-alarm-admin", rollbackKey, "ack-test", ep2.ID, func(tx *sql.Tx) ([]byte, error) {
		if _, err := e2.st.AcknowledgeEpisodeTx(e2.ctx(), tx, e2.tenant, ep2.ID, "native-alarm-admin", runtime.NewID()); err != nil {
			return nil, err
		}
		return nil, forced
	})
	if !errors.Is(err, forced) {
		t.Fatalf("rollback error=%v", err)
	}
	unchanged, err := e2.st.GetEpisodeByID(e2.ctx(), e2.tenant, ep2.ID)
	if err != nil || unchanged.AckedAt != nil || unchanged.AckedBy != "" {
		t.Fatalf("failed write left acknowledgement: %+v err=%v", unchanged, err)
	}
	if _, found, err := e2.st.LookupRequest(e2.ctx(), e2.tenant, rollbackKey); err != nil || found {
		t.Fatalf("failed write left receipt: found=%v err=%v", found, err)
	}
}

func TestNativeAutomationRejectsPlatformAndForgedScopeAuthority(t *testing.T) {
	for _, data := range []*authn.Data{
		{UserID: "platform", TenantID: "tenant-a", Roles: []string{"SYS_ADMIN", "TENANT_ADMIN"}},
		{UserID: "scoped", TenantID: "tenant-a", Roles: []string{"TENANT_ADMIN"}, AuthorizedDeviceIDs: []string{"device-a"}},
		{UserID: "untrusted", TenantID: "tenant-a", Roles: []string{"TENANT_USER"}, Scopes: []string{"*"}},
	} {
		et.OverrideAuthInfo(auth.UID(data.UserID), data)
		if _, err := mustTenant(); errs.Code(err) != errs.PermissionDenied {
			t.Fatalf("principal %+v was accepted: %v", data, err)
		}
	}
	et.OverrideAuthInfo("", nil)
}

func TestNativeDeviceAutomationEffectiveParamsMergeTemplateAndDevice(t *testing.T) {
	e := newEnv(t)
	nativeScopeAuth(t, e.tenant, "effective-params-admin")
	s := &Service{rt: e.rt}
	def := paramRule(e, "20")
	def.Params = append(def.Params, domain.Param{Key: "label", Type: domain.ParamString, Default: "default-label"})
	def.Trigger.Groups[0].Conditions = append(def.Trigger.Groups[0].Conditions, domain.Condition{Source: "self", Signal: domain.SignalTelemetry, Key: "label", Operator: domain.OpEq, Value: "{{label}}"})
	rule := e.createRule(def)
	e.bind(rule, "device_config", "cfg-1", map[string]string{"limit": "30", "label": "template-label"})
	e.bind(rule, "device", e.dev1, map[string]string{"limit": "60"})
	response, err := s.GetDeviceAutomation(e.ctx(), e.dev1)
	if err != nil {
		t.Fatal(err)
	}
	for _, row := range response.Rules {
		if row.RuleID == rule.ID {
			if row.Source != "device" || row.Effective["limit"] != "60" || row.Effective["label"] != "template-label" || len(row.Overridden) != 1 || row.Overridden[0] != "limit" {
				t.Fatalf("displayed values differ from runtime inheritance: %+v", row)
			}
			return
		}
	}
	t.Fatal("bound rule missing")
}
