package automationowner

import (
	"context"
	"encoding/json"
	"testing"

	"encore.app/devicemetadata"
	"encore.dev/beta/errs"
)

func TestNativeDirectoryMapsNativeSnapshotAndRequiresCompleteTenantScopedResult(t *testing.T) {
	tenant := "11111111-0000-0000-0000-000000000000"
	template := "22222222-2222-4222-8222-222222222222"
	var gotReq *devicemetadata.ResolveAutomationDirectoryRequest
	d := &nativeDirectory{resolve: func(_ context.Context, req *devicemetadata.ResolveAutomationDirectoryRequest) (*devicemetadata.ResolveAutomationDirectoryResponse, error) {
		gotReq = req
		return &devicemetadata.ResolveAutomationDirectoryResponse{Complete: true, Devices: []devicemetadata.NativeAutomationDirectoryDevice{{ID: "33333333-3333-4333-8333-333333333333", TenantID: tenant, Name: "pump", TemplateID: &template, DeviceKind: "gateway", Labels: json.RawMessage(`{"area":"west"}`)}}}, nil
	}}
	got, err := d.ByIDs(context.Background(), "11111111", []string{"33333333-3333-4333-8333-333333333333"})
	if err != nil {
		t.Fatal(err)
	}
	if gotReq.TenantID != tenant || gotReq.Selector != "ids" {
		t.Fatalf("request normalization/selector: %+v", gotReq)
	}
	if len(got) != 1 || got[0].DeviceConfigID != template || got[0].DeviceType != "2" || got[0].Online != -1 || got[0].Capabilities != nil || got[0].Label != "area=west" {
		t.Fatalf("unexpected native mapping: %+v", got)
	}
	if _, err := (&nativeDirectory{resolve: func(context.Context, *devicemetadata.ResolveAutomationDirectoryRequest) (*devicemetadata.ResolveAutomationDirectoryResponse, error) {
		return &devicemetadata.ResolveAutomationDirectoryResponse{}, nil
	}}).ByIDs(context.Background(), tenant, nil); errs.Code(err) != errs.Unavailable {
		t.Fatalf("incomplete response error=%v", err)
	}
	if _, err := (&nativeDirectory{resolve: func(context.Context, *devicemetadata.ResolveAutomationDirectoryRequest) (*devicemetadata.ResolveAutomationDirectoryResponse, error) {
		return &devicemetadata.ResolveAutomationDirectoryResponse{Complete: true, Devices: []devicemetadata.NativeAutomationDirectoryDevice{{TenantID: "44444444-4444-4444-8444-444444444444"}}}, nil
	}}).ByIDs(context.Background(), tenant, nil); errs.Code(err) != errs.Unavailable {
		t.Fatalf("cross-tenant response error=%v", err)
	}
}

func TestNativeDirectoryTypeAcceptsNativeKindsWithoutInventingSensor(t *testing.T) {
	for kind, want := range map[string]string{"standalone": "1", "gateway": "2", "subdevice": "3", "1": "1", "2": "2", "3": "3"} {
		got, ok := legacyDeviceType(kind)
		if !ok || got != want {
			t.Errorf("%q => %q,%v", kind, got, ok)
		}
	}
	if _, ok := legacyDeviceType("sensor"); ok {
		t.Fatal("unsupported sensor kind was invented")
	}
}

func TestNativeDirectoryValidatesScopeUsingPrivateOwner(t *testing.T) {
	tenant := "11111111-0000-0000-0000-000000000000"
	scopeID := "22222222-2222-4222-8222-222222222222"
	var got *devicemetadata.ValidateAutomationScopeRequest
	d := &nativeDirectory{resolveScope: func(_ context.Context, req *devicemetadata.ValidateAutomationScopeRequest) (*devicemetadata.ValidateAutomationScopeResponse, error) {
		got = req
		return &devicemetadata.ValidateAutomationScopeResponse{ID: req.ScopeID, ScopeType: req.ScopeType}, nil
	}}
	if err := d.ValidateScope(context.Background(), "11111111", "device_config", scopeID); err != nil {
		t.Fatal(err)
	}
	if got.TenantID != tenant || got.ScopeID != scopeID || got.ScopeType != "device_config" {
		t.Fatalf("unexpected scope RPC request: %+v", got)
	}
	notFound := &errs.Error{Code: errs.NotFound, Message: "not found"}
	d.resolveScope = func(context.Context, *devicemetadata.ValidateAutomationScopeRequest) (*devicemetadata.ValidateAutomationScopeResponse, error) {
		return nil, notFound
	}
	if err := d.ValidateScope(context.Background(), tenant, "device", scopeID); errs.Code(err) != errs.NotFound {
		t.Fatalf("missing target code = %v, want NotFound", err)
	}
}
