package devicemetadata

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"encore.dev/beta/errs"
	"github.com/google/uuid"
)

const nativeTemplateMQTTConfiguration = `{"deviceKind":"standalone","model":null,"access":{"mode":"direct","protocol":"mqtt","providerId":null,"parameters":{},"credentialPolicy":{"kind":"none","autoRegister":false},"onlinePolicy":{"mode":"transport","timeoutSeconds":60},"connectionDirection":"device_to_platform","serviceInstanceId":null},"topicMappings":[],"processingScripts":[],"customFieldDefinitions":[]}`

func nativeTemplateWriteTestIdentity(tenantID string) nativeTemplateWriteIdentity {
	return nativeTemplateWriteIdentity{nativeTemplateReadIdentity: nativeTemplateReadIdentity{tenantID: tenantID}, subjectID: "template-write-test"}
}

func nativeTemplateWriteTestBody(t *testing.T, name, configuration string) []byte {
	t.Helper()
	body, err := json.Marshal(map[string]any{"name": name, "configuration": json.RawMessage(configuration)})
	if err != nil {
		t.Fatal(err)
	}
	return body
}

func nativeTemplateWriteTestResult(t *testing.T, result *metadataWriteResponse) NativeDeviceAccessTemplate {
	t.Helper()
	var response NativeDeviceAccessTemplateResponse
	if result == nil || json.Unmarshal(result.Body, &response) != nil || response.Data.ID == "" {
		t.Fatal("invalid template mutation response")
	}
	return response.Data
}

func TestNativeTemplateCreateDirectSaveReplayConflictAndCAS(t *testing.T) {
	requireDeviceGroupPostgres(t)
	ctx := context.Background()
	tenantID := testTenantID()
	identity := nativeTemplateWriteTestIdentity(tenantID)
	body := nativeTemplateWriteTestBody(t, "direct-save-template", nativeTemplateMQTTConfiguration)
	created, err := createNativeTemplate(ctx, identity, "template-create-001", body, "template-create-request", validateNativeDeviceConfiguration, nil)
	if err != nil {
		t.Fatal(err)
	}
	template := nativeTemplateWriteTestResult(t, created)
	if created.Status != 201 || created.Location != "/api/v2/device-access-templates/"+template.ID || template.ResourceVersion != 1 || created.ETag == "" {
		t.Fatalf("unexpected create: %+v", created)
	}
	if strings.Contains(string(created.Body), "draft") || strings.Contains(string(created.Body), "latestPublishedRevision") || strings.Contains(string(created.Body), "imageUrl") {
		t.Fatal("withdrawn lifecycle or capability field in template response")
	}
	replay, err := createNativeTemplate(ctx, identity, "template-create-001", body, "different-request-id", validateNativeDeviceConfiguration, nil)
	if err != nil || !replay.Replayed || string(replay.Body) != string(created.Body) || replay.RequestID != created.RequestID {
		t.Fatalf("create replay changed: replay=%+v err=%v", replay, err)
	}
	if _, err := createNativeTemplate(ctx, identity, "template-create-001", nativeTemplateWriteTestBody(t, "changed-input", nativeTemplateMQTTConfiguration), "changed-request", validateNativeDeviceConfiguration, nil); errs.Code(err) != errs.AlreadyExists {
		t.Fatalf("different input must conflict: %v", err)
	}
	if _, err := createNativeTemplate(ctx, identity, "template-create-002", body, "duplicate-name", validateNativeDeviceConfiguration, nil); errs.Code(err) != errs.AlreadyExists {
		t.Fatalf("same-tenant duplicate name must conflict: %v", err)
	}
	patch := []byte(`{"name":"saved-now","description":"current configuration"}`)
	updated, err := updateNativeTemplate(ctx, identity, template.ID, "template-update-001", created.ETag, patch, "template-update-request", validateNativeDeviceConfiguration, nil)
	if err != nil {
		t.Fatal(err)
	}
	saved := nativeTemplateWriteTestResult(t, updated)
	if saved.Name != "saved-now" || saved.ResourceVersion != 2 || updated.ETag == created.ETag || saved.Description == nil || *saved.Description != "current configuration" {
		t.Fatalf("direct update not visible: %+v", saved)
	}
	replayedUpdate, err := updateNativeTemplate(ctx, identity, template.ID, "template-update-001", created.ETag, patch, "different-update-request", validateNativeDeviceConfiguration, nil)
	if err != nil || !replayedUpdate.Replayed || string(replayedUpdate.Body) != string(updated.Body) {
		t.Fatalf("patch replay changed: %+v %v", replayedUpdate, err)
	}
	if _, err := updateNativeTemplate(ctx, identity, template.ID, "template-stale-001", created.ETag, []byte(`{"name":"overwrite"}`), "stale-request", validateNativeDeviceConfiguration, nil); errs.Code(err) != errs.FailedPrecondition {
		t.Fatalf("stale patch must fail: %v", err)
	}
	noOp, err := updateNativeTemplate(ctx, identity, template.ID, "template-noop-001", updated.ETag, []byte(`{}`), "noop-request", validateNativeDeviceConfiguration, nil)
	if err != nil || nativeTemplateWriteTestResult(t, noOp).ResourceVersion != 2 || noOp.ETag != updated.ETag {
		t.Fatalf("empty patch changed resource: %+v %v", noOp, err)
	}
	changedKind, _ := json.Marshal(map[string]json.RawMessage{"configuration": json.RawMessage(strings.Replace(nativeTemplateMQTTConfiguration, `"deviceKind":"standalone"`, `"deviceKind":"gateway"`, 1))})
	if _, err := updateNativeTemplate(ctx, identity, template.ID, "template-kind-001", updated.ETag, changedKind, "kind-change-request", validateNativeDeviceConfiguration, nil); err == nil {
		t.Fatal("template editing must preserve the existing device kind")
	}
	var auditCount, receiptCount, failedReceipts int
	if err := db.QueryRow(ctx, `SELECT count(*) FROM metadata_audit_events WHERE tenant_id=$1 AND resource_id=$2`, tenantID, template.ID).Scan(&auditCount); err != nil {
		t.Fatal(err)
	}
	if err := db.QueryRow(ctx, `SELECT count(*) FROM metadata_idempotency WHERE tenant_id=$1 AND state='completed'`, tenantID).Scan(&receiptCount); err != nil {
		t.Fatal(err)
	}
	if err := db.QueryRow(ctx, `SELECT count(*) FROM metadata_idempotency WHERE tenant_id=$1 AND idempotency_key='template-stale-001'`, tenantID).Scan(&failedReceipts); err != nil {
		t.Fatal(err)
	}
	if auditCount != 3 || receiptCount != 3 || failedReceipts != 0 {
		t.Fatalf("mutation/replay audit boundary: audits=%d receipts=%d failed=%d", auditCount, receiptCount, failedReceipts)
	}
	if _, err := readNativeTemplate(ctx, nativeTemplateReadIdentity{tenantID: testTenantID()}, template.ID); errs.Code(err) != errs.NotFound {
		t.Fatalf("cross-tenant read: %v", err)
	}
}

func TestNativeTemplateAssetReferenceValidationAndSafeReceipt(t *testing.T) {
	requireDeviceGroupPostgres(t)
	ctx := context.Background()
	identity := nativeTemplateWriteTestIdentity(testTenantID())
	assetID := uuid.NewString()
	var body map[string]any
	_ = json.Unmarshal(nativeTemplateWriteTestBody(t, "template-cover", nativeTemplateMQTTConfiguration), &body)
	body["configuration"] = json.RawMessage(nativeTemplateMQTTConfiguration)
	body["imageAssetId"] = assetID
	encoded, _ := json.Marshal(body)
	if _, err := createNativeTemplate(ctx, identity, "asset-reference-001", encoded, "missing-asset-owner", validateNativeDeviceConfiguration, nil); errs.Code(err) != errs.Unavailable {
		t.Fatalf("missing asset owner must refuse write: %v", err)
	}
	called := 0
	check := func(_ context.Context, tenant, id string) error {
		called++
		if tenant != identity.tenantID || id != assetID {
			t.Fatal("asset owner received untrusted scope")
		}
		return nil
	}
	result, err := createNativeTemplate(ctx, identity, "asset-reference-002", encoded, "asset-reference-request", validateNativeDeviceConfiguration, check)
	if err != nil {
		t.Fatal(err)
	}
	template := nativeTemplateWriteTestResult(t, result)
	if called != 1 || template.ImageAssetID == nil || *template.ImageAssetID != assetID {
		t.Fatal("validated asset identity not retained")
	}
	var storedReceipt string
	if err := db.QueryRow(ctx, `SELECT response::text FROM metadata_idempotency WHERE tenant_id=$1 AND idempotency_key='asset-reference-002'`, identity.tenantID).Scan(&storedReceipt); err != nil {
		t.Fatal(err)
	}
	for _, forbidden := range []string{"imageUrl", "downloadUrl", "X-Amz-", "https://"} {
		if strings.Contains(storedReceipt, forbidden) {
			t.Fatalf("capability in metadata receipt: %s", forbidden)
		}
	}
}

func TestNativeTemplateMutationProblemKeepsConditionalAndBusinessConflictsSeparate(t *testing.T) {
	for _, tc := range []struct {
		name   string
		err    error
		status int
	}{
		{"stale ETag", errNativeTemplateETagMismatch, http.StatusPreconditionFailed},
		{"unavailable model binding", &errs.Error{Code: errs.FailedPrecondition, Message: "model is archived"}, http.StatusConflict},
		{"invalid kind", invalid("configuration.deviceKind", "device kind cannot be changed"), http.StatusUnprocessableEntity},
		{"structural input", invalidStructure("duplicate property"), http.StatusBadRequest},
		{"unexpected storage failure", fmt.Errorf("private database credential detail"), http.StatusInternalServerError},
	} {
		t.Run(tc.name, func(t *testing.T) {
			w := httptest.NewRecorder()
			r := httptest.NewRequest(http.MethodPatch, "/api/v2/device-access-templates/test", nil)
			writeNativeTemplateMutationError(w, r, "template-problem-request", tc.err, true)
			if w.Code != tc.status || w.Header().Get("Content-Type") != "application/problem+json" || strings.Contains(w.Body.String(), "private database credential detail") {
				t.Fatalf("unsafe or incorrect template Problem: status=%d body=%s", w.Code, w.Body.String())
			}
		})
	}
}
