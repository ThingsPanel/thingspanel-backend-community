package devicemetadata

import (
	"bytes"
	"encoding/json"

	"encore.app/devicemetadata/accessconfig"
)

// NativeTemplateCreateInput is a locally validated create request. ConfigurationJSON
// retains exact numeric values; Configuration is the validated, convenient value form.
type NativeTemplateCreateInput struct {
	Name              string
	Description       NativeDeviceField[string]
	Brand             NativeDeviceField[string]
	ProductName       NativeDeviceField[string]
	ModelNumber       NativeDeviceField[string]
	Tags              []string
	Configuration     accessconfig.Configuration
	ConfigurationJSON json.RawMessage
	ImageAssetID      NativeDeviceField[string]
	CanonicalBody     []byte
}

// NativeTemplatePatchInput preserves field presence for explicit partial
// replacement. A supplied Configuration is a complete replacement, never a merge.
type NativeTemplatePatchInput struct {
	Name                NativeDeviceField[string]
	Description         NativeDeviceField[string]
	Brand               NativeDeviceField[string]
	ProductName         NativeDeviceField[string]
	ModelNumber         NativeDeviceField[string]
	Tags                NativeDeviceField[[]string]
	Configuration       NativeDeviceField[accessconfig.Configuration]
	ConfigurationJSON   NativeDeviceField[json.RawMessage]
	AdministrativeState NativeDeviceField[string]
	ImageAssetID        NativeDeviceField[string]
	CanonicalBody       []byte
}

// ParseNativeTemplateCreate validates only the local request contract. It does
// not resolve catalog ownership or provider/model capabilities.
func ParseNativeTemplateCreate(data []byte) (*NativeTemplateCreateInput, error) {
	fields, err := strictJSONObject(data)
	if err != nil {
		return nil, err
	}
	if err := rejectUnknown(fields, setOf("name", "description", "brand", "productName", "modelNumber", "tags", "configuration", "imageAssetId")); err != nil {
		return nil, err
	}
	out := &NativeTemplateCreateInput{Tags: []string{}}
	if err := requiredString(fields, "name", 1, 128, &out.Name); err != nil {
		return nil, err
	}
	if raw, ok := fields["configuration"]; !ok {
		return nil, invalid("configuration", "required")
	} else if err := decodeTemplateConfiguration(raw, &out.Configuration, &out.ConfigurationJSON); err != nil {
		return nil, err
	}
	if err := decodeTemplateOptionalString(fields, "description", 0, 2000, &out.Description); err != nil {
		return nil, err
	}
	if err := decodeTemplateOptionalString(fields, "brand", 0, 64, &out.Brand); err != nil {
		return nil, err
	}
	if err := decodeTemplateOptionalString(fields, "productName", 0, 128, &out.ProductName); err != nil {
		return nil, err
	}
	if err := decodeTemplateOptionalString(fields, "modelNumber", 0, 64, &out.ModelNumber); err != nil {
		return nil, err
	}
	if raw, ok := fields["tags"]; ok {
		if err := decodeStringArray(raw, "tags", 32, 64, false, &out.Tags); err != nil {
			return nil, err
		}
	}
	if raw, ok := fields["imageAssetId"]; ok {
		if err := decodeTemplateImageAssetID(raw, &out.ImageAssetID); err != nil {
			return nil, err
		}
	}
	body := map[string]any{"name": out.Name, "description": nullableFieldValue(out.Description), "brand": nullableFieldValue(out.Brand), "productName": nullableFieldValue(out.ProductName), "modelNumber": nullableFieldValue(out.ModelNumber), "tags": out.Tags, "configuration": out.ConfigurationJSON, "imageAssetId": nullableFieldValue(out.ImageAssetID)}
	out.CanonicalBody, err = json.Marshal(body)
	if err != nil {
		return nil, invalidStructure("could not canonicalize request")
	}
	return out, nil
}

// ParseNativeTemplatePatch validates a strict partial replacement request.
// Empty objects are accepted as contract-valid no-ops.
func ParseNativeTemplatePatch(data []byte) (*NativeTemplatePatchInput, error) {
	fields, err := strictJSONObject(data)
	if err != nil {
		return nil, err
	}
	if err := rejectUnknown(fields, setOf("name", "description", "brand", "productName", "modelNumber", "tags", "configuration", "administrativeState", "imageAssetId")); err != nil {
		return nil, err
	}
	out := &NativeTemplatePatchInput{}
	if raw, ok := fields["name"]; ok {
		if err := decodeFieldString(raw, "name", 1, 128, false, &out.Name); err != nil {
			return nil, err
		}
	}
	for _, spec := range []struct {
		key string
		max int
		dst *NativeDeviceField[string]
	}{{"description", 2000, &out.Description}, {"brand", 64, &out.Brand}, {"productName", 128, &out.ProductName}, {"modelNumber", 64, &out.ModelNumber}} {
		if raw, ok := fields[spec.key]; ok {
			if err := decodeTemplateOptionalStringValue(raw, spec.key, 0, spec.max, spec.dst); err != nil {
				return nil, err
			}
		}
	}
	if raw, ok := fields["tags"]; ok {
		var tags []string
		if err := decodeStringArray(raw, "tags", 32, 64, false, &tags); err != nil {
			return nil, err
		}
		out.Tags = NativeDeviceField[[]string]{Present: true, Value: tags}
	}
	if raw, ok := fields["configuration"]; ok {
		var d accessconfig.Configuration
		var rawConfiguration json.RawMessage
		if err := decodeTemplateConfiguration(raw, &d, &rawConfiguration); err != nil {
			return nil, err
		}
		out.Configuration = NativeDeviceField[accessconfig.Configuration]{Present: true, Value: d}
		out.ConfigurationJSON = NativeDeviceField[json.RawMessage]{Present: true, Value: rawConfiguration}
	}
	if raw, ok := fields["administrativeState"]; ok {
		var state string
		if err := decodeString(raw, "administrativeState", &state); err != nil {
			return nil, err
		}
		if state != "enabled" && state != "disabled" {
			return nil, invalid("administrativeState", "value is not in the allowed enum")
		}
		out.AdministrativeState = NativeDeviceField[string]{Present: true, Value: state}
	}
	if raw, ok := fields["imageAssetId"]; ok {
		if err := decodeTemplateImageAssetID(raw, &out.ImageAssetID); err != nil {
			return nil, err
		}
	}
	body := make(map[string]any, len(fields))
	for key, field := range map[string]NativeDeviceField[string]{"name": out.Name, "description": out.Description, "brand": out.Brand, "productName": out.ProductName, "modelNumber": out.ModelNumber, "administrativeState": out.AdministrativeState, "imageAssetId": out.ImageAssetID} {
		if field.Present {
			body[key] = nullableFieldValue(field)
		}
	}
	if out.Tags.Present {
		body["tags"] = out.Tags.Value
	}
	if out.ConfigurationJSON.Present {
		body["configuration"] = out.ConfigurationJSON.Value
	}
	out.CanonicalBody, err = json.Marshal(body)
	if err != nil {
		return nil, invalidStructure("could not canonicalize request")
	}
	return out, nil
}

func decodeTemplateOptionalString(fields map[string]json.RawMessage, key string, min, max int, dst *NativeDeviceField[string]) error {
	raw, ok := fields[key]
	if !ok {
		*dst = NativeDeviceField[string]{Present: true, Null: true}
		return nil
	}
	return decodeTemplateOptionalStringValue(raw, key, min, max, dst)
}

func decodeTemplateOptionalStringValue(raw []byte, key string, min, max int, dst *NativeDeviceField[string]) error {
	if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		*dst = NativeDeviceField[string]{Present: true, Null: true}
		return nil
	}
	var value string
	if err := decodeString(raw, key, &value); err != nil {
		return err
	}
	if err := checkText(key, value, min, max); err != nil {
		return err
	}
	*dst = NativeDeviceField[string]{Present: true, Value: value}
	return nil
}

func decodeTemplateImageAssetID(raw []byte, dst *NativeDeviceField[string]) error {
	if bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
		*dst = NativeDeviceField[string]{Present: true, Null: true}
		return nil
	}
	var value string
	if err := decodeString(raw, "imageAssetId", &value); err != nil {
		return err
	}
	canonical, err := nativeReadUUID(value)
	if err != nil {
		return invalid("imageAssetId", "must be a canonical non-zero UUID")
	}
	*dst = NativeDeviceField[string]{Present: true, Value: canonical}
	return nil
}

func decodeTemplateConfiguration(raw []byte, dst *accessconfig.Configuration, canonical *json.RawMessage) error {
	if err := rejectDuplicateJSONKeys(raw); err != nil {
		return err
	}
	configuration, err := accessconfig.DecodeConfiguration(raw)
	if err != nil {
		return invalid("configuration", "does not match the TemplateConfiguration contract")
	}
	encoded, err := canonicalizeJSON(raw)
	if err != nil {
		return invalid("configuration", "invalid JSON value")
	}
	*dst = configuration
	*canonical = encoded
	return nil
}

// rejectDuplicateJSONKeys walks every object, including arbitrary JSON values
// such as access parameters and script samples. Decoder.Token applies Go's
// standard JSON nesting limit; errors deliberately do not include key values.
func rejectDuplicateJSONKeys(raw []byte) error {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	tok, err := dec.Token()
	if err != nil {
		return invalid("configuration", "invalid JSON value")
	}
	if err := walkUniqueJSONValue(dec, tok); err != nil {
		return err
	}
	if err := ensureEOF(dec); err != nil {
		return invalid("configuration", "invalid JSON value")
	}
	return nil
}

func walkUniqueJSONValue(dec *json.Decoder, tok json.Token) error {
	delim, ok := tok.(json.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := make(map[string]struct{})
		for dec.More() {
			keyToken, err := dec.Token()
			if err != nil {
				return invalid("configuration", "invalid JSON value")
			}
			key, ok := keyToken.(string)
			if !ok {
				return invalid("configuration", "invalid JSON value")
			}
			if _, exists := seen[key]; exists {
				return invalidStructure("duplicate property")
			}
			seen[key] = struct{}{}
			value, err := dec.Token()
			if err != nil {
				return invalid("configuration", "invalid JSON value")
			}
			if err := walkUniqueJSONValue(dec, value); err != nil {
				return err
			}
		}
		end, err := dec.Token()
		if err != nil || end != json.Delim('}') {
			return invalid("configuration", "invalid JSON value")
		}
	case '[':
		for dec.More() {
			value, err := dec.Token()
			if err != nil {
				return invalid("configuration", "invalid JSON value")
			}
			if err := walkUniqueJSONValue(dec, value); err != nil {
				return err
			}
		}
		end, err := dec.Token()
		if err != nil || end != json.Delim(']') {
			return invalid("configuration", "invalid JSON value")
		}
	default:
		return invalid("configuration", "invalid JSON value")
	}
	return nil
}

func canonicalizeJSON(raw []byte) (json.RawMessage, error) {
	dec := json.NewDecoder(bytes.NewReader(raw))
	dec.UseNumber()
	var value any
	if err := dec.Decode(&value); err != nil {
		return nil, err
	}
	if err := ensureEOF(dec); err != nil {
		return nil, err
	}
	out, err := json.Marshal(value)
	return json.RawMessage(out), err
}

func nullableFieldValue(field NativeDeviceField[string]) any {
	if !field.Present || field.Null {
		return nil
	}
	return field.Value
}
