package verifier

import (
	"context"
	"strings"
	"time"

	"encore.app/l1-access/authn"
	"encore.app/internal/authz"
	"encore.app/internal/closedloop"
	"fmt"
)

//encore:service
type Service struct{}

type VerifyRequest struct {
	TargetDeviceID            string `json:"target_device_id"`
	RuleID                    string `json:"rule_id"`
	TriggerKey                string `json:"trigger_key"`
	TriggerValue              string `json:"trigger_value"`
	VerificationWindowSeconds int    `json:"verification_window_seconds"`
}

type VerifyData struct {
	Pass                      bool   `json:"pass"`
	BaselineNotificationTotal int    `json:"baseline_notification_total"`
	AfterNotificationTotal    int    `json:"after_notification_total"`
	NotificationDelta         int    `json:"notification_delta"`
	RuleID                    string `json:"rule_id"`
	TargetDeviceID            string `json:"target_device_id"`
	TriggerKey                string `json:"trigger_key"`
	TriggerValue              string `json:"trigger_value"`
	VerificationWindowSeconds int    `json:"verification_window_seconds"`
	EvidenceTimestamp         string `json:"evidence_timestamp"`
}

type VerifyEnvelope struct {
	Code      int        `json:"code"`
	Message   string     `json:"message"`
	RequestID string     `json:"requestId"`
	Data      VerifyData `json:"data"`
}

//encore:api auth method=POST path=/v1/closed-loop/verify
func (s *Service) Verify(ctx context.Context, req *VerifyRequest) (*VerifyEnvelope, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if req == nil || strings.TrimSpace(req.TargetDeviceID) == "" {
		return &VerifyEnvelope{Code: 400, Message: "target_device_id required", RequestID: "req-verify-closed-loop"}, nil
	}
	if !authz.CanDevice(ad, "view", req.TargetDeviceID) {
		return nil, fmt.Errorf("no view permission on device")
	}
	key := strings.TrimSpace(req.TriggerKey)
	if key == "" {
		key = "switch"
	}
	val := strings.TrimSpace(req.TriggerValue)
	if val == "" {
		val = "1"
	}
	window := req.VerificationWindowSeconds
	if window <= 0 {
		window = 24
	}

	baseline := closedloop.NotificationTotal()
	delta := closedloop.ProcessTelemetry(req.TargetDeviceID, key, val)
	after := closedloop.NotificationTotal()
	pass := delta > 0 && after > baseline

	return &VerifyEnvelope{
		Code:      200,
		Message:   "verify completed",
		RequestID: "req-verify-closed-loop",
		Data: VerifyData{
			Pass:                      pass,
			BaselineNotificationTotal: baseline,
			AfterNotificationTotal:    after,
			NotificationDelta:         delta,
			RuleID:                    req.RuleID,
			TargetDeviceID:            req.TargetDeviceID,
			TriggerKey:                key,
			TriggerValue:              val,
			VerificationWindowSeconds: window,
			EvidenceTimestamp:         time.Now().UTC().Format(time.RFC3339),
		},
	}, nil
}
