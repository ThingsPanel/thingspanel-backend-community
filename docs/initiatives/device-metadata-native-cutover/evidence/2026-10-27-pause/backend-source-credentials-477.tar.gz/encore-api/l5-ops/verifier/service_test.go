package verifier

import (
	"context"
	"testing"

	"encore.app/internal/closedloop"
)

func TestVerifyClosedLoopPass(t *testing.T) {
	closedloop.CreateRule("test-rule", "dev-1", "switch", "1")
	svc := &Service{}
	resp, err := svc.Verify(context.Background(), &VerifyRequest{
		TargetDeviceID: "dev-1",
		TriggerKey:     "switch",
		TriggerValue:   "1",
	})
	if err != nil {
		t.Fatalf("Verify err: %v", err)
	}
	if resp.Code != 200 || !resp.Data.Pass || resp.Data.NotificationDelta <= 0 {
		t.Fatalf("unexpected resp: %+v", resp)
	}
}

func TestVerifyClosedLoopFailWithoutRule(t *testing.T) {
	svc := &Service{}
	resp, err := svc.Verify(context.Background(), &VerifyRequest{
		TargetDeviceID: "dev-no-rule",
		TriggerKey:     "switch",
		TriggerValue:   "1",
	})
	if err != nil {
		t.Fatalf("Verify err: %v", err)
	}
	if resp.Code != 200 || resp.Data.Pass || resp.Data.NotificationDelta != 0 {
		t.Fatalf("unexpected resp: %+v", resp)
	}
}
