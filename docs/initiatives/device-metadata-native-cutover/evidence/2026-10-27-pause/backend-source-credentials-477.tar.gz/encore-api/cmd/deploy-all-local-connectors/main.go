package main

import (
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"time"

	"encore.app/l3-core/pluginmgr"
	"gopkg.in/yaml.v3"
)

type manifest struct {
	Metadata manifestMetadata `yaml:"metadata"`
	Spec     manifestSpec     `yaml:"spec"`

	ConnectorKey      string         `yaml:"connectorKey"`
	DisplayName       string         `yaml:"displayName"`
	MQTTTopicPrefix   string         `yaml:"mqttTopicPrefix"`
	DeviceTypeSupport flexibleString `yaml:"deviceTypeSupport"`
	Description       string         `yaml:"description"`
	AdditionalInfo    map[string]any `yaml:"additionalInfo"`
}

type manifestMetadata struct {
	Name         string `yaml:"name"`
	DisplayName  string `yaml:"displayName"`
	ConnectorKey string `yaml:"connectorKey"`
}

type manifestSpec struct {
	MQTTTopicPrefix      string         `yaml:"mqttTopicPrefix"`
	DeviceTypeSupport    flexibleString `yaml:"deviceTypeSupport"`
	HTTPCallbacksEnabled *bool          `yaml:"httpCallbacksEnabled"`
	AdditionalInfo       map[string]any `yaml:"additionalInfo"`
}

type flexibleString string

func (s *flexibleString) UnmarshalYAML(node *yaml.Node) error {
	switch node.Kind {
	case yaml.ScalarNode:
		*s = flexibleString(strings.TrimSpace(node.Value))
	case yaml.SequenceNode:
		values := make([]string, 0, len(node.Content))
		for _, item := range node.Content {
			if strings.TrimSpace(item.Value) != "" {
				values = append(values, strings.TrimSpace(item.Value))
			}
		}
		*s = flexibleString(strings.Join(values, ","))
	}
	return nil
}

type connectorDef struct {
	Key                  string
	DisplayName          string
	MQTTTopicPrefix      string
	DeviceTypeSupport    string
	HTTPCallbacksEnabled *bool
	Description          string
	AdditionalInfo       map[string]any
	Path                 string
}

type result struct {
	Created []string `json:"created"`
	Updated []string `json:"updated"`
	Skipped []string `json:"skipped"`
}

func main() {
	defaultDir := filepath.Clean("../examples/device-connectors")
	manifestsDir := flag.String("manifests-dir", defaultDir, "directory containing connector subdirectories")
	dryRun := flag.Bool("dry-run", false, "print planned connector catalog changes without writing")
	flag.Parse()

	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Minute)
	defer cancel()

	defs, err := loadConnectorDefs(*manifestsDir)
	if err != nil {
		fatal(err)
	}
	out, err := applyConnectorDefs(ctx, defs, *dryRun)
	if err != nil {
		fatal(err)
	}

	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		fatal(err)
	}
}

func loadConnectorDefs(root string) ([]connectorDef, error) {
	matches, err := filepath.Glob(filepath.Join(root, "*", "device-connector.yaml"))
	if err != nil {
		return nil, err
	}
	if len(matches) == 0 {
		return nil, fmt.Errorf("no device-connector.yaml files found under %s", root)
	}
	sort.Strings(matches)

	defs := make([]connectorDef, 0, len(matches))
	for _, path := range matches {
		def, err := readConnectorDef(path)
		if err != nil {
			return nil, err
		}
		defs = append(defs, def)
	}
	return defs, nil
}

func readConnectorDef(path string) (connectorDef, error) {
	raw, err := os.ReadFile(path)
	if err != nil {
		return connectorDef{}, err
	}
	var m manifest
	if err := yaml.Unmarshal(raw, &m); err != nil {
		return connectorDef{}, fmt.Errorf("%s: parse yaml: %w", path, err)
	}

	dirName := filepath.Base(filepath.Dir(path))
	key := firstNonEmpty(m.Metadata.ConnectorKey, m.ConnectorKey, m.Metadata.Name, dirName)
	displayName := firstNonEmpty(m.Metadata.DisplayName, m.DisplayName, key+" 接入服务")
	prefix := normalizeMQTTPrefix(key, firstNonEmpty(m.Spec.MQTTTopicPrefix, m.MQTTTopicPrefix, "plugin/"+key+"/"))
	deviceType := normalizeDeviceType(firstNonEmpty(string(m.Spec.DeviceTypeSupport), string(m.DeviceTypeSupport), "gateway"))
	description := firstNonEmpty(m.Description, displayName)
	additionalInfo := mergeInfo(m.AdditionalInfo, m.Spec.AdditionalInfo)
	normalizeAdditionalInfo(additionalInfo, deviceType)

	if key == "" {
		return connectorDef{}, fmt.Errorf("%s: connector key is empty", path)
	}
	return connectorDef{
		Key:                  key,
		DisplayName:          displayName,
		MQTTTopicPrefix:      prefix,
		DeviceTypeSupport:    deviceType,
		HTTPCallbacksEnabled: m.Spec.HTTPCallbacksEnabled,
		Description:          description,
		AdditionalInfo:       additionalInfo,
		Path:                 path,
	}, nil
}

func applyConnectorDefs(ctx context.Context, defs []connectorDef, dryRun bool) (result, error) {
	var out result
	existing, err := pluginmgr.ListDeviceConnectorsForDeploy(ctx, &pluginmgr.ListDeviceConnectorsRequest{Page: 1, PageSize: 500})
	if err != nil {
		return out, fmt.Errorf("list existing device connectors: %w", err)
	}
	byKey := map[string]pluginmgr.DeviceConnector{}
	for _, dc := range existing.List {
		byKey[dc.ConnectorKey] = dc
	}

	for _, def := range defs {
		if strings.TrimSpace(def.Key) == "" {
			out.Skipped = append(out.Skipped, def.Path)
			continue
		}
		rawInfo, err := json.Marshal(def.AdditionalInfo)
		if err != nil {
			return out, fmt.Errorf("%s: marshal additional info: %w", def.Key, err)
		}
		if current, ok := byKey[def.Key]; ok {
			out.Updated = append(out.Updated, def.Key)
			if dryRun {
				continue
			}
			_, err := pluginmgr.UpdateDeviceConnectorForDeploy(ctx, current.ID, &pluginmgr.UpdateDeviceConnectorRequest{
				DisplayName:     def.DisplayName,
				MQTTTopicPrefix: def.MQTTTopicPrefix,
				Description:     def.Description,
				AdditionalInfo:  rawInfo,
			})
			if err != nil {
				return out, fmt.Errorf("update %s: %w", def.Key, err)
			}
			continue
		}

		out.Created = append(out.Created, def.Key)
		if dryRun {
			continue
		}
		_, err = pluginmgr.CreateDeviceConnectorForDeploy(ctx, &pluginmgr.CreateDeviceConnectorRequest{
			ConnectorKey:         def.Key,
			DisplayName:          def.DisplayName,
			MQTTTopicPrefix:      def.MQTTTopicPrefix,
			DeviceTypeSupport:    def.DeviceTypeSupport,
			HTTPCallbacksEnabled: def.HTTPCallbacksEnabled,
			Description:          def.Description,
			AdditionalInfo:       rawInfo,
		})
		if err != nil {
			return out, fmt.Errorf("create %s: %w", def.Key, err)
		}
	}
	return out, nil
}

func normalizeDeviceType(value string) string {
	normalized := strings.ToLower(strings.TrimSpace(value))
	if strings.Contains(normalized, ",") {
		parts := strings.Split(normalized, ",")
		if len(parts) > 1 {
			return "both"
		}
		normalized = strings.TrimSpace(parts[0])
	}
	switch normalized {
	case "direct", "gateway", "both":
		return normalized
	default:
		return "gateway"
	}
}

func normalizeMQTTPrefix(key string, value string) string {
	normalized := strings.TrimSpace(value)
	if normalized == "" || normalized == key {
		normalized = "plugin/" + key + "/"
	}
	if !strings.HasSuffix(normalized, "/") {
		normalized += "/"
	}
	return normalized
}

func normalizeAdditionalInfo(info map[string]any, deviceType string) {
	if info == nil {
		return
	}
	kind := strings.TrimSpace(fmt.Sprint(info["integration_kind"]))
	if kind == "" {
		if deviceType == "direct" {
			info["integration_kind"] = "service_access"
		} else {
			info["integration_kind"] = "gateway_access"
		}
	}
	if _, ok := info["legacy_service_type"]; ok {
		return
	}
	if strings.EqualFold(fmt.Sprint(info["integration_kind"]), "service_access") {
		info["legacy_service_type"] = 2
	}
}

func mergeInfo(values ...map[string]any) map[string]any {
	out := map[string]any{}
	for _, value := range values {
		for k, v := range value {
			out[k] = v
		}
	}
	return out
}

func firstNonEmpty(values ...string) string {
	for _, value := range values {
		if strings.TrimSpace(value) != "" {
			return strings.TrimSpace(value)
		}
	}
	return ""
}

func fatal(err error) {
	if err == nil || errors.Is(err, flag.ErrHelp) {
		return
	}
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
