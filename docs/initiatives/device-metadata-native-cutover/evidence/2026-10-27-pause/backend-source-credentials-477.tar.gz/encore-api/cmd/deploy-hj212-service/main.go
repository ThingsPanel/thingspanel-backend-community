package main

import (
	"fmt"
	"os"

	"encore.app/cmd/internal/deployutil"
)

func main() {
	cfg := deployutil.Config{
		ConnectorKey:      "hj212",
		DisplayName:       "HJ-212 污染源在线监控",
		MQTTTopicPrefix:   "plugin/hj212/",
		DeviceTypeSupport: "gateway",
		Description:       "HJ-212 gateway connector for environmental monitoring devices",
		ImageEnv:          "HJ212_SERVICE_IMAGE",
		DefaultImage:      "hj212-service:1.2.1",
		NamespaceEnv:      "HJ212_SERVICE_NAMESPACE",
		DefaultNamespace:  "connector-instances",
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		IntegrationKind:   "protocol_access",
		LegacyServiceType: 1,
		ExtraEnv: map[string]string{
			"HJ212_LISTEN_ADDR": getenv("HJ212_LISTEN_ADDR", "0.0.0.0:9212"),
		},
	}
	if err := deployutil.Run(cfg); err != nil {
		fatal(err)
	}
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func fatal(err error) {
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
	os.Exit(1)
}
