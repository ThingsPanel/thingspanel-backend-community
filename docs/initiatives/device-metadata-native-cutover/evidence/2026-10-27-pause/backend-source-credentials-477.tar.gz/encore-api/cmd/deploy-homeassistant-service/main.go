package main

import (
	"context"
	"crypto/sha256"
	"database/sql"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"encore.app/l3-core/pluginmgr"
	_ "github.com/jackc/pgx/v5/stdlib"
)

type deployResult struct {
	Connector pluginmgr.DeviceConnector         `json:"connector"`
	Runtime   pluginmgr.ConnectorRuntime        `json:"runtime"`
	Instance  pluginmgr.ConnectorInstance       `json:"instance"`
	Binding   *pluginmgr.ConnectorBinding       `json:"binding,omitempty"`
	Status    *pluginmgr.ConnectorStatus        `json:"status,omitempty"`
	Events    *pluginmgr.ConnectorEventListData `json:"events,omitempty"`
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	setDefaultEnv("TP_CONNECTOR_DB_DSN", "postgres://postgres:postgresThingsPanel@127.0.0.1:5555/ThingsPanel?sslmode=disable")
	setDefaultEnv("CONNECTOR_RUNNER", "k8s")

	image := getenv("HOMEASSISTANT_SERVICE_IMAGE", "homeassistant-service:1.0.0")
	namespace := getenv("HOMEASSISTANT_SERVICE_NAMESPACE", "connector-instances")
	backendURL := getenv("THINGSPANEL_BACKEND_URL", "http://host.docker.internal:9999")
	dsn := os.Getenv("TP_CONNECTOR_DB_DSN")

	deviceID := getenv("HA_TP_DEVICE_ID", "f0b4290e-d9b1-4a00-9000-000000000109")
	devicePassword := getenv("HA_MQTT_PASSWORD", "localdev")
	baseURL := getenv("HA_BASE_URL", "http://100.121.58.108:8123")
	entityID := getenv("HA_ENTITY_ID", getenv("HA_LIGHT_ENTITY_ID", getenv("HA_YEELIGHT_ENTITY_ID", "light.yeelink_mono1_d9b1_light")))
	token := getenv("HA_ACCESS_TOKEN", getenv("HOME_ASSISTANT_TOKEN", ""))

	deviceNumber := strings.TrimSpace(os.Getenv("HA_MQTT_USERNAME"))
	if deviceNumber == "" {
		deviceNumber = normalizedDeviceNumber("ha", entityID)
	}

	if err := ensureHomeAssistantDevice(ctx, dsn, deviceID, deviceNumber, devicePassword, baseURL, entityID); err != nil {
		fatal(fmt.Errorf("ensure homeassistant device: %w", err))
	}
	if err := retireLegacyXiaomiPlugDevice(ctx, dsn); err != nil {
		fatal(fmt.Errorf("retire legacy xiaomi-plug device: %w", err))
	}

	svc := &pluginmgr.Service{}
	httpCB := true
	connector, err := findConnector(ctx, svc, "homeassistant")
	if err != nil {
		fatal(err)
	}
	if connector == nil {
		additionalInfo, err := json.Marshal(map[string]interface{}{
			"integration_kind":    "service_access",
			"legacy_service_type": 2,
			"supported_modes":     []string{"homeassistant"},
		})
		if err != nil {
			fatal(fmt.Errorf("marshal connector additional info: %w", err))
		}
		connector, err = svc.CreateDeviceConnector(ctx, &pluginmgr.CreateDeviceConnectorRequest{
			ConnectorKey:         "homeassistant",
			DisplayName:          "HomeAssistant 接入服务",
			MQTTTopicPrefix:      "plugin/homeassistant/",
			DeviceTypeSupport:    "direct",
			HTTPCallbacksEnabled: &httpCB,
			Description:          "Standalone Home Assistant third-party access service",
			AdditionalInfo:       additionalInfo,
		})
		if err != nil {
			fatal(fmt.Errorf("create device connector: %w", err))
		}
	}

	envVars := map[string]string{
		"CONNECTOR_SERVICE_IDENTIFIER": "homeassistant",
		"THINGSPANEL_BACKEND_URL":      backendURL,
		"LOG_LEVEL":                    "info",
		"TP_MQTT_BROKER":               getenv("TP_MQTT_BROKER", "tcp://host.docker.internal:1883"),
		"TP_MQTT_USER":                 getenv("TP_MQTT_USER", "root"),
		"TP_MQTT_PASS":                 getenv("TP_MQTT_PASS", "root"),
		"HA_TP_DEVICE_ID":              deviceID,
		"HA_MQTT_USERNAME":             deviceNumber,
		"HA_MQTT_PASSWORD":             devicePassword,
		"HA_BASE_URL":                  baseURL,
		"HA_ENTITY_ID":                 entityID,
	}
	if token != "" {
		envVars["HA_ACCESS_TOKEN"] = token
	}

	runtime, err := svc.CreateConnectorRuntime(ctx, &pluginmgr.CreateConnectorRuntimeRequest{
		DeviceConnectorID: connector.ID,
		Image:             image,
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		EnvVars:           envVars,
		ResourceLimits: &pluginmgr.ResourceLimits{
			CPURequest:    "100m",
			CPULimit:      "500m",
			MemoryRequest: "64Mi",
			MemoryLimit:   "256Mi",
		},
		Description: "homeassistant service K8S runtime",
	})
	if err != nil {
		fatal(fmt.Errorf("create connector runtime: %w", err))
	}

	instance, err := svc.CreateConnectorInstance(ctx, &pluginmgr.CreateConnectorInstanceRequest{
		ConnectorRuntimeID: runtime.ID,
		Namespace:          namespace,
	})
	if err != nil {
		fatal(fmt.Errorf("create connector instance: %w", err))
	}

	binding, _ := svc.CreateConnectorBinding(ctx, &pluginmgr.CreateConnectorBindingRequest{
		ConnectorInstanceID: instance.ID,
		DeviceID:            deviceID,
		Voucher:             deviceNumber,
	})
	status, _ := svc.GetConnectorInstanceStatus(ctx, instance.ID)
	events, _ := svc.ListConnectorInstanceEvents(ctx, instance.ID, &pluginmgr.ListConnectorEventsRequest{Page: 1, PageSize: 20})

	outRuntime := *runtime
	outRuntime.EnvVars = maskEnvVars(outRuntime.EnvVars)
	out := deployResult{Connector: *connector, Runtime: outRuntime, Instance: *instance, Binding: binding, Status: status, Events: events}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		fatal(err)
	}
}

func findConnector(ctx context.Context, svc *pluginmgr.Service, key string) (*pluginmgr.DeviceConnector, error) {
	list, err := svc.ListDeviceConnectors(ctx, &pluginmgr.ListDeviceConnectorsRequest{Page: 1, PageSize: 100})
	if err != nil {
		return nil, fmt.Errorf("list device connectors: %w", err)
	}
	for i := range list.List {
		if list.List[i].ConnectorKey == key {
			return &list.List[i], nil
		}
	}
	return nil, nil
}

func ensureHomeAssistantDevice(ctx context.Context, dsn, deviceID, deviceNumber, password, baseURL, entityID string) error {
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return err
	}
	defer db.Close()

	domain := entityDomain(entityID)
	protocolConfig, err := json.Marshal(map[string]string{
		"entity_id":     entityID,
		"domain":        domain,
		"base_url":      baseURL,
		"device_number": deviceNumber,
	})
	if err != nil {
		return err
	}

	additionalInfo, err := json.Marshal(map[string]any{
		"source":             "homeassistant-service",
		"base_url":           baseURL,
		"entity_id":          entityID,
		"supports_brightness": domain == "light",
	})
	if err != nil {
		return err
	}

	voucher, err := json.Marshal(map[string]string{
		"username":  deviceNumber,
		"password":  password,
		"base_url":  baseURL,
		"entity_id": entityID,
	})
	if err != nil {
		return err
	}

	deviceConfigID := getenv("HA_DEVICE_CONFIG_ID", "8ab14a5b-95d8-4f54-9f49-3d2d02ad7003")

	if _, err := db.ExecContext(ctx, `
		INSERT INTO device_configs (
			id, name, protocol_type, device_type, protocol_config, description, tenant_id, created_at, updated_at
		) VALUES (
			$1, 'HomeAssistant Service Default', 'homeassistant', '1', '{}'::json, 'Created by deploy-homeassistant-service', 'J8gc5ibL', now(), now()
		)
		ON CONFLICT (id) DO UPDATE SET
			protocol_type = EXCLUDED.protocol_type,
			protocol_config = EXCLUDED.protocol_config,
			updated_at = now()
	`, deviceConfigID); err != nil {
		return fmt.Errorf("upsert device_config: %w", err)
	}

	_, err = db.ExecContext(ctx, `
		INSERT INTO devices (
			id, name, voucher, tenant_id, is_enabled, activate_flag,
			created_at, update_at, device_number, additional_info,
			protocol_config, is_online, access_way, description, device_config_id
		) VALUES (
			$1, $2, $3, 'J8gc5ibL', 'enable', 'active',
			now(), now(), $4, $5::json,
			$6::json, 1, 'mqtt', 'Bound to HomeAssistant service connector', $7
		)
		ON CONFLICT (id) DO UPDATE SET
			name = EXCLUDED.name,
			voucher = EXCLUDED.voucher,
			device_number = EXCLUDED.device_number,
			update_at = now(),
			is_online = 1,
			additional_info = EXCLUDED.additional_info,
			protocol_config = EXCLUDED.protocol_config,
			description = EXCLUDED.description,
			device_config_id = EXCLUDED.device_config_id
	`, deviceID, "HomeAssistant Yeelight", string(voucher), deviceNumber, string(additionalInfo), string(protocolConfig), deviceConfigID)
	return err
}

// retireLegacyXiaomiPlugDevice disables the historical yeelight-f0b4290ed9b1 row that
// was bound to the retired xiaomi-plug connector. Local control now goes only through
// homeassistant-service and ha-* device numbers.
func retireLegacyXiaomiPlugDevice(ctx context.Context, dsn string) error {
	if getenv("RETIRE_LEGACY_XIAOMI_PLUG", "1") != "1" {
		return nil
	}
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return err
	}
	defer db.Close()

	legacyID := getenv("LEGACY_XIAOMI_PLUG_DEVICE_ID", "f0b4290e-d9b1-4a00-9000-000000000108")
	_, err = db.ExecContext(ctx, `
		UPDATE devices SET
			is_enabled = 'disable',
			update_at = now(),
			description = 'Retired: replaced by homeassistant-service (see deploy-homeassistant-service)'
		WHERE id = $1 AND device_number = 'yeelight-f0b4290ed9b1'
	`, legacyID)
	return err
}

// normalizedDeviceNumber mirrors examples/device-connectors/homeassistant-service/handler.go
// so deploy seeds match connector discovery and MQTT command routing.
func normalizedDeviceNumber(prefix, value string) string {
	source := strings.ToLower(strings.TrimSpace(value))
	replacer := strings.NewReplacer(".", "-", "_", "-", " ", "-", "/", "-", ":", "-")
	normalized := replacer.Replace(source)
	var b strings.Builder
	lastDash := false
	for _, r := range normalized {
		allowed := (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9')
		if allowed {
			b.WriteRune(r)
			lastDash = false
			continue
		}
		if !lastDash {
			b.WriteByte('-')
			lastDash = true
		}
	}
	slug := strings.Trim(b.String(), "-")
	if slug == "" {
		slug = "device"
	}
	result := prefix + "-" + slug
	if len(result) <= 36 {
		return result
	}
	hash := sha256.Sum256([]byte(source))
	suffix := hex.EncodeToString(hash[:4])
	maxReadable := 36 - 1 - len(suffix)
	readable := result
	if len(readable) > maxReadable {
		readable = strings.TrimRight(readable[:maxReadable], "-")
	}
	return readable + "-" + suffix
}

func entityDomain(entityID string) string {
	entityID = strings.TrimSpace(entityID)
	if idx := strings.Index(entityID, "."); idx > 0 {
		return strings.ToLower(entityID[:idx])
	}
	return ""
}

func setDefaultEnv(key, value string) {
	if strings.TrimSpace(os.Getenv(key)) == "" {
		_ = os.Setenv(key, value)
	}
}

func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func maskEnvVars(values map[string]string) map[string]string {
	masked := make(map[string]string, len(values))
	for key, value := range values {
		upperKey := strings.ToUpper(key)
		if strings.Contains(upperKey, "TOKEN") || strings.Contains(upperKey, "PASS") {
			masked[key] = "***"
			continue
		}
		masked[key] = value
	}
	return masked
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
