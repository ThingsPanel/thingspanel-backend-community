package main

import (
	"fmt"
	"os"

	"encore.app/cmd/internal/deployutil"
)

func main() {
	cfg := deployutil.Config{
		ConnectorKey:      "udp-generic",
		DisplayName:       "Generic UDP Connector",
		MQTTTopicPrefix:   "plugin/udp-generic/",
		DeviceTypeSupport: "gateway",
		Description:       "Generic UDP device connector for datagram-based protocols",
		ImageEnv:          "UDP_GENERIC_IMAGE",
		DefaultImage:      "udp-generic:1.0.0",
		NamespaceEnv:      "UDP_GENERIC_NAMESPACE",
		DefaultNamespace:  "connector-instances",
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		IntegrationKind:   "gateway",
		ExtraEnv: map[string]string{
			"UDP_LISTEN_PORT":    getenv("UDP_LISTEN_PORT", "9000"),
			"UDP_CODEC":          getenv("UDP_CODEC", "json"),
			"UDP_DEVICE_ID_PATH": getenv("UDP_DEVICE_ID_PATH", "device.id"),
		},
	}
	if err := deployutil.Run(cfg); err != nil {
		fatal(err)
	}
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func fatal(err error) {
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
	os.Exit(1)
}
