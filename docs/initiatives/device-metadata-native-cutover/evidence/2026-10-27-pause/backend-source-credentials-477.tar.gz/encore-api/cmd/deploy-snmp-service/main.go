package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"encore.app/l3-core/pluginmgr"
)

type deployResult struct {
	Connector pluginmgr.DeviceConnector   `json:"connector"`
	Runtime   pluginmgr.ConnectorRuntime  `json:"runtime"`
	Instance  pluginmgr.ConnectorInstance `json:"instance"`
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	image := getenv("SNMP_SERVICE_IMAGE", "snmp-service:1.0.0")
	namespace := getenv("SNMP_SERVICE_NAMESPACE", "connector-instances")
	backendURL := getenv("THINGSPANEL_BACKEND_URL", "http://host.docker.internal:9999")

	svc := &pluginmgr.Service{}
	httpCB := true
	connector, err := findConnector(ctx, svc, "snmp")
	if err != nil {
		fatal(err)
	}
	if connector == nil {
		connector, err = svc.CreateDeviceConnector(ctx, &pluginmgr.CreateDeviceConnectorRequest{
			ConnectorKey:         "snmp",
			DisplayName:          "SNMP 接入服务",
			MQTTTopicPrefix:      "plugin/snmp/",
			DeviceTypeSupport:    "gateway",
			HTTPCallbacksEnabled: &httpCB,
			Description:          "Standalone SNMP access service",
			AdditionalInfo:       json.RawMessage(`{"integration_kind":"service_access","supported_modes":["snmp"]}`),
		})
		if err != nil {
			fatal(fmt.Errorf("create device connector: %w", err))
		}
	}

	envVars := map[string]string{
		"CONNECTOR_SERVICE_IDENTIFIER": "snmp",
		"THINGSPANEL_BACKEND_URL":      backendURL,
		"LOG_LEVEL":                    "info",
		"TP_MQTT_BROKER":               getenv("TP_MQTT_BROKER", "tcp://host.docker.internal:1883"),
		"TP_MQTT_USER":                 getenv("TP_MQTT_USER", "root"),
		"TP_MQTT_PASS":                 getenv("TP_MQTT_PASS", "root"),
	}

	// For test/direct deployment support
	if c := getenv("SNMP_COMMUNITY", ""); c != "" {
		envVars["SNMP_COMMUNITY"] = c
	}
	if a := getenv("SNMP_AUTH_PASSWORD", ""); a != "" {
		envVars["SNMP_AUTH_PASSWORD"] = a
	}
	if p := getenv("SNMP_PRIVACY_PASSWORD", ""); p != "" {
		envVars["SNMP_PRIVACY_PASSWORD"] = p
	}

	runtime, err := svc.CreateConnectorRuntime(ctx, &pluginmgr.CreateConnectorRuntimeRequest{
		DeviceConnectorID: connector.ID,
		Image:             image,
		HTTPPort:          9005,
		HealthCheckPath:   "/health",
		EnvVars:           envVars,
		ResourceLimits: &pluginmgr.ResourceLimits{
			CPURequest:    "100m",
			CPULimit:      "500m",
			MemoryRequest: "64Mi",
			MemoryLimit:   "256Mi",
		},
		Description: "snmp service K8S runtime",
	})
	if err != nil {
		fatal(fmt.Errorf("create connector runtime: %w", err))
	}

	instance, err := svc.CreateConnectorInstance(ctx, &pluginmgr.CreateConnectorInstanceRequest{
		ConnectorRuntimeID: runtime.ID,
		Namespace:          namespace,
	})
	if err != nil {
		fatal(fmt.Errorf("create connector instance: %w", err))
	}

	outRuntime := *runtime
	outRuntime.EnvVars = maskEnvVars(outRuntime.EnvVars)

	out := deployResult{Connector: *connector, Runtime: outRuntime, Instance: *instance}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		fatal(err)
	}
}

func findConnector(ctx context.Context, svc *pluginmgr.Service, key string) (*pluginmgr.DeviceConnector, error) {
	list, err := svc.ListDeviceConnectors(ctx, &pluginmgr.ListDeviceConnectorsRequest{Page: 1, PageSize: 100})
	if err != nil {
		return nil, fmt.Errorf("list device connectors: %w", err)
	}
	for i := range list.List {
		if list.List[i].ConnectorKey == key {
			return &list.List[i], nil
		}
	}
	return nil, nil
}

func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func maskEnvVars(values map[string]string) map[string]string {
	masked := make(map[string]string, len(values))
	for key, value := range values {
		upperKey := strings.ToUpper(key)
		if strings.Contains(upperKey, "COMMUNITY") || strings.Contains(upperKey, "PASSWORD") {
			masked[key] = "***"
			continue
		}
		masked[key] = value
	}
	return masked
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
