package deployutil

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"encore.app/l3-core/pluginmgr"
)

type Config struct {
	ConnectorKey      string
	DisplayName       string
	MQTTTopicPrefix   string
	DeviceTypeSupport string
	Description       string
	ImageEnv          string
	DefaultImage      string
	NamespaceEnv      string
	DefaultNamespace  string
	HTTPPort          int
	HealthCheckPath   string
	IntegrationKind   string
	LegacyServiceType int
	ExtraEnv          map[string]string
}

type deployResult struct {
	Connector pluginmgr.DeviceConnector   `json:"connector"`
	Runtime   pluginmgr.ConnectorRuntime  `json:"runtime"`
	Instance  pluginmgr.ConnectorInstance `json:"instance"`
}

func Run(cfg Config) error {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	setDefaultEnv("TP_CONNECTOR_DB_DSN", "postgres://postgres:postgresThingsPanel@127.0.0.1:5555/ThingsPanel?sslmode=disable")
	setDefaultEnv("CONNECTOR_RUNNER", "k8s")

	image := getenv(cfg.ImageEnv, cfg.DefaultImage)
	namespace := getenv(cfg.NamespaceEnv, cfg.DefaultNamespace)
	backendURL := getenv("THINGSPANEL_BACKEND_URL", "http://host.docker.internal:9999")

	httpCB := true
	connector, err := findConnector(ctx, cfg.ConnectorKey)
	if err != nil {
		return err
	}
	additionalInfoJSON, err := buildAdditionalInfo(cfg)
	if err != nil {
		return err
	}
	var connectorID string
	if connector == nil {
		connector, err = pluginmgr.CreateDeviceConnectorForDeploy(ctx, &pluginmgr.CreateDeviceConnectorRequest{
			ConnectorKey:         cfg.ConnectorKey,
			DisplayName:          cfg.DisplayName,
			MQTTTopicPrefix:      cfg.MQTTTopicPrefix,
			DeviceTypeSupport:    cfg.DeviceTypeSupport,
			HTTPCallbacksEnabled: &httpCB,
			Description:          cfg.Description,
			AdditionalInfo:       additionalInfoJSON,
		})
		if err != nil {
			return fmt.Errorf("create device connector: %w", err)
		}
		connectorID = connector.ID
	} else {
		connectorID = connector.ID
		connector, err = pluginmgr.UpdateDeviceConnectorForDeploy(ctx, connector.ID, &pluginmgr.UpdateDeviceConnectorRequest{
			DisplayName:     cfg.DisplayName,
			MQTTTopicPrefix: cfg.MQTTTopicPrefix,
			Description:     cfg.Description,
			AdditionalInfo:  additionalInfoJSON,
		})
		if err != nil {
			return fmt.Errorf("update device connector: %w", err)
		}
		if connector != nil && connector.ID != "" {
			connectorID = connector.ID
		}
	}

	envVars := map[string]string{
		"CONNECTOR_SERVICE_IDENTIFIER": cfg.ConnectorKey,
		"THINGSPANEL_BACKEND_URL":      backendURL,
		"LOG_LEVEL":                    "info",
		"TP_MQTT_BROKER":               getenv("TP_MQTT_BROKER", "tcp://host.docker.internal:1883"),
		"TP_MQTT_USER":                 getenv("TP_MQTT_USER", "root"),
		"TP_MQTT_PASS":                 getenv("TP_MQTT_PASS", "root"),
	}
	for key, value := range cfg.ExtraEnv {
		if value != "" {
			envVars[key] = value
		}
	}

	healthPath := cfg.HealthCheckPath
	if healthPath == "" {
		healthPath = "/health"
	}
	httpPort := cfg.HTTPPort
	if httpPort <= 0 {
		httpPort = 9001
	}

	runtime, err := pluginmgr.CreateConnectorRuntimeForDeploy(ctx, &pluginmgr.CreateConnectorRuntimeRequest{
		DeviceConnectorID: connectorID,
		Image:             image,
		HTTPPort:          httpPort,
		HealthCheckPath:   healthPath,
		EnvVars:           envVars,
		ResourceLimits: &pluginmgr.ResourceLimits{
			CPURequest:    "100m",
			CPULimit:      "500m",
			MemoryRequest: "64Mi",
			MemoryLimit:   "256Mi",
		},
		Description: cfg.ConnectorKey + " service K8S runtime",
	})
	if err != nil {
		return fmt.Errorf("create connector runtime: %w", err)
	}

	instance, err := pluginmgr.CreateConnectorInstanceForDeploy(ctx, &pluginmgr.CreateConnectorInstanceRequest{
		ConnectorRuntimeID: runtime.ID,
		Namespace:          namespace,
	})
	if err != nil {
		return fmt.Errorf("create connector instance: %w", err)
	}
	if connector == nil {
		connector, err = findConnector(ctx, cfg.ConnectorKey)
		if err != nil {
			return fmt.Errorf("reload device connector: %w", err)
		}
	}
	if connector == nil {
		return fmt.Errorf("device connector %q not found after deploy", cfg.ConnectorKey)
	}

	outRuntime := *runtime
	outRuntime.EnvVars = maskEnvVars(outRuntime.EnvVars)
	out := deployResult{Connector: *connector, Runtime: outRuntime, Instance: *instance}

	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	return enc.Encode(out)
}

func buildAdditionalInfo(cfg Config) (json.RawMessage, error) {
	additionalInfo := map[string]any{}
	if cfg.IntegrationKind != "" {
		additionalInfo["integration_kind"] = cfg.IntegrationKind
	}
	if cfg.LegacyServiceType > 0 {
		additionalInfo["legacy_service_type"] = cfg.LegacyServiceType
	}
	data, err := json.Marshal(additionalInfo)
	if err != nil {
		return nil, fmt.Errorf("marshal connector additional info: %w", err)
	}
	return data, nil
}

func findConnector(ctx context.Context, key string) (*pluginmgr.DeviceConnector, error) {
	list, err := pluginmgr.ListDeviceConnectorsForDeploy(ctx, &pluginmgr.ListDeviceConnectorsRequest{Page: 1, PageSize: 200})
	if err != nil {
		return nil, fmt.Errorf("list device connectors: %w", err)
	}
	for i := range list.List {
		if list.List[i].ConnectorKey == key {
			return &list.List[i], nil
		}
	}
	return nil, nil
}

func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func setDefaultEnv(key, value string) {
	if strings.TrimSpace(os.Getenv(key)) == "" {
		_ = os.Setenv(key, value)
	}
}

func maskEnvVars(values map[string]string) map[string]string {
	masked := make(map[string]string, len(values))
	for key, value := range values {
		upperKey := strings.ToUpper(key)
		if strings.Contains(upperKey, "TOKEN") || strings.Contains(upperKey, "PASS") || strings.Contains(upperKey, "KEY") || strings.Contains(upperKey, "SECRET") {
			masked[key] = "***"
			continue
		}
		masked[key] = value
	}
	return masked
}
