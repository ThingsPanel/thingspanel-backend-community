package main

import (
	"fmt"
	"os"

	"encore.app/cmd/internal/deployutil"
)

func main() {
	cfg := deployutil.Config{
		ConnectorKey:      "serial-generic",
		DisplayName:       "Generic Serial Connector",
		MQTTTopicPrefix:   "plugin/serial-generic/",
		DeviceTypeSupport: "gateway",
		Description:       "Generic serial (RS232/RS485) device connector",
		ImageEnv:          "SERIAL_GENERIC_IMAGE",
		DefaultImage:      "serial-generic:1.0.0",
		NamespaceEnv:      "SERIAL_GENERIC_NAMESPACE",
		DefaultNamespace:  "connector-instances",
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		IntegrationKind:   "gateway",
		ExtraEnv: map[string]string{
			"SERIAL_PORT":       getenv("SERIAL_PORT", "/dev/ttyUSB0"),
			"SERIAL_BAUD_RATE":  getenv("SERIAL_BAUD_RATE", "9600"),
			"SERIAL_FRAME_MODE": getenv("SERIAL_FRAME_MODE", "line"),
			"SERIAL_CODEC":      getenv("SERIAL_CODEC", "json"),
		},
	}
	if err := deployutil.Run(cfg); err != nil {
		fatal(err)
	}
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func fatal(err error) {
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
	os.Exit(1)
}
