package main

import (
	"fmt"
	"os"
	"strconv"
	"strings"

	"encore.app/cmd/internal/deployutil"
)

func main() {
	connectorKey := strings.TrimSpace(os.Getenv("CONNECTOR_KEY"))
	if connectorKey == "" {
		fatal(fmt.Errorf("CONNECTOR_KEY is required"))
	}

	httpPort := 9001
	if raw := strings.TrimSpace(os.Getenv("CONNECTOR_HTTP_PORT")); raw != "" {
		port, err := strconv.Atoi(raw)
		if err != nil || port <= 0 {
			fatal(fmt.Errorf("invalid CONNECTOR_HTTP_PORT: %q", raw))
		}
		httpPort = port
	}

	displayName := getenv("CONNECTOR_DISPLAY_NAME", connectorKey+" 接入服务")
	mqttPrefix := getenv("CONNECTOR_MQTT_TOPIC_PREFIX", "plugin/"+connectorKey+"/")
	deviceTypeSupport := getenv("CONNECTOR_DEVICE_TYPE_SUPPORT", "gateway")
	description := getenv("CONNECTOR_DESCRIPTION", "Generic deploy command managed connector")
	integrationKind := getenv("CONNECTOR_INTEGRATION_KIND", "service_access")

	legacyServiceType := 0
	if raw := strings.TrimSpace(os.Getenv("CONNECTOR_LEGACY_SERVICE_TYPE")); raw != "" {
		v, err := strconv.Atoi(raw)
		if err != nil {
			fatal(fmt.Errorf("invalid CONNECTOR_LEGACY_SERVICE_TYPE: %q", raw))
		}
		legacyServiceType = v
	}

	cfg := deployutil.Config{
		ConnectorKey:      connectorKey,
		DisplayName:       displayName,
		MQTTTopicPrefix:   mqttPrefix,
		DeviceTypeSupport: deviceTypeSupport,
		Description:       description,
		ImageEnv:          "CONNECTOR_IMAGE",
		DefaultImage:      connectorKey + "-service:1.0.0",
		NamespaceEnv:      "CONNECTOR_NAMESPACE",
		DefaultNamespace:  "connector-instances",
		HTTPPort:          httpPort,
		HealthCheckPath:   "/health",
		IntegrationKind:   integrationKind,
		LegacyServiceType: legacyServiceType,
	}
	if err := deployutil.Run(cfg); err != nil {
		fatal(err)
	}
}

func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
