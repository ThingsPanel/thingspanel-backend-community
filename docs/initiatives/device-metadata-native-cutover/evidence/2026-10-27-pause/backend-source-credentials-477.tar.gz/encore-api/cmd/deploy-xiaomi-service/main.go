package main

import (
	"context"
	"database/sql"
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"time"

	"encore.app/l3-core/pluginmgr"
	_ "github.com/jackc/pgx/v5/stdlib"
)

type deployResult struct {
	Connector pluginmgr.DeviceConnector         `json:"connector"`
	Runtime   pluginmgr.ConnectorRuntime        `json:"runtime"`
	Instance  pluginmgr.ConnectorInstance       `json:"instance"`
	Binding   *pluginmgr.ConnectorBinding       `json:"binding,omitempty"`
	Status    *pluginmgr.ConnectorStatus        `json:"status,omitempty"`
	Events    *pluginmgr.ConnectorEventListData `json:"events,omitempty"`
}

func main() {
	ctx, cancel := context.WithTimeout(context.Background(), 4*time.Minute)
	defer cancel()

	setDefaultEnv("TP_CONNECTOR_DB_DSN", "postgres://postgres:postgresThingsPanel@127.0.0.1:5555/ThingsPanel?sslmode=disable")
	setDefaultEnv("CONNECTOR_RUNNER", "k8s")

	image := getenv("XIAOMI_SERVICE_IMAGE", "xiaomi-service:1.0.0")
	namespace := getenv("XIAOMI_SERVICE_NAMESPACE", "connector-instances")
	backendURL := getenv("THINGSPANEL_BACKEND_URL", "http://host.docker.internal:9999")
	dsn := os.Getenv("TP_CONNECTOR_DB_DSN")

	deviceID := getenv("XIAOMI_TP_DEVICE_ID", "f0b4290e-d9b1-4a00-9000-000000000108")
	deviceNumber := getenv("XIAOMI_MQTT_USERNAME", "yeelight-f0b4290ed9b1")
	devicePassword := getenv("XIAOMI_MQTT_PASSWORD", "localdev")
	deviceDID := getenv("XIAOMI_DEVICE_DID", "13224775")
	deviceIP := getenv("XIAOMI_LAN_IP", "192.168.31.108")
	deviceToken := getenv("XIAOMI_LAN_TOKEN", "")
	deviceModel := getenv("XIAOMI_DEVICE_MODEL", getenv("XIAOMI_LAN_MODEL", "yeelink.light.mono1"))

	if err := ensureXiaomiDevice(ctx, dsn, deviceID, deviceNumber, devicePassword, deviceDID, deviceIP, deviceModel); err != nil {
		fatal(fmt.Errorf("ensure xiaomi device: %w", err))
	}

	svc := &pluginmgr.Service{}
	httpCB := true
	connector, err := findConnector(ctx, svc, "xiaomi")
	if err != nil {
		fatal(err)
	}
	if connector == nil {
		connector, err = svc.CreateDeviceConnector(ctx, &pluginmgr.CreateDeviceConnectorRequest{
			ConnectorKey:         "xiaomi",
			DisplayName:          "小米接入服务",
			MQTTTopicPrefix:      "plugin/xiaomi/",
			DeviceTypeSupport:    "direct",
			HTTPCallbacksEnabled: &httpCB,
			Description:          "Standalone Xiaomi third-party access service with cloud and LAN modes",
			AdditionalInfo:       json.RawMessage(`{"integration_kind":"service_access","legacy_service_type":2,"supported_modes":["xiaomi_cloud","xiaomi_lan"]}`),
		})
		if err != nil {
			fatal(fmt.Errorf("create device connector: %w", err))
		}
	}

	envVars := map[string]string{
		"CONNECTOR_SERVICE_IDENTIFIER": "xiaomi",
		"THINGSPANEL_BACKEND_URL":      backendURL,
		"LOG_LEVEL":                    "info",
		"XIAOMI_ACCESS_MODE":           getenv("XIAOMI_ACCESS_MODE", "xiaomi_cloud"),
		"XIAOMI_CLOUD_SERVER":          getenv("XIAOMI_CLOUD_SERVER", "cn"),
		"TP_MQTT_BROKER":               getenv("TP_MQTT_BROKER", "tcp://host.docker.internal:1883"),
		"TP_MQTT_USER":                 getenv("TP_MQTT_USER", "root"),
		"TP_MQTT_PASS":                 getenv("TP_MQTT_PASS", "root"),
		"XIAOMI_TP_DEVICE_ID":          deviceID,
		"XIAOMI_MQTT_USERNAME":         deviceNumber,
		"XIAOMI_MQTT_PASSWORD":         devicePassword,
		"XIAOMI_DEVICE_DID":            deviceDID,
		"XIAOMI_LAN_IP":                deviceIP,
		"XIAOMI_DEVICE_MODEL":          deviceModel,
		"XIAOMI_LAN_MODEL":             deviceModel,
		"XIAOMI_ON_SIID":               getenv("XIAOMI_ON_SIID", "2"),
		"XIAOMI_ON_PIID":               getenv("XIAOMI_ON_PIID", "1"),
		"XIAOMI_BRIGHTNESS_SIID":       getenv("XIAOMI_BRIGHTNESS_SIID", "2"),
		"XIAOMI_BRIGHTNESS_PIID":       getenv("XIAOMI_BRIGHTNESS_PIID", "2"),
	}
	if deviceToken != "" {
		envVars["XIAOMI_LAN_TOKEN"] = deviceToken
	}
	if oauthJSON := strings.TrimSpace(os.Getenv("XIAOMI_OAUTH_JSON")); oauthJSON != "" {
		envVars["XIAOMI_OAUTH_JSON"] = oauthJSON
	}
	if oauthFile := strings.TrimSpace(os.Getenv("XIAOMI_OAUTH_FILE")); oauthFile != "" {
		raw, err := os.ReadFile(oauthFile)
		if err != nil {
			fatal(fmt.Errorf("read XIAOMI_OAUTH_FILE: %w", err))
		}
		envVars["XIAOMI_OAUTH_JSON"] = strings.TrimSpace(string(raw))
	}

	runtime, err := svc.CreateConnectorRuntime(ctx, &pluginmgr.CreateConnectorRuntimeRequest{
		DeviceConnectorID: connector.ID,
		Image:             image,
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		EnvVars:           envVars,
		ResourceLimits: &pluginmgr.ResourceLimits{
			CPURequest:    "100m",
			CPULimit:      "500m",
			MemoryRequest: "64Mi",
			MemoryLimit:   "256Mi",
		},
		Description: "xiaomi service K8S runtime",
	})
	if err != nil {
		fatal(fmt.Errorf("create connector runtime: %w", err))
	}

	instance, err := svc.CreateConnectorInstance(ctx, &pluginmgr.CreateConnectorInstanceRequest{
		ConnectorRuntimeID: runtime.ID,
		Namespace:          namespace,
	})
	if err != nil {
		fatal(fmt.Errorf("create connector instance: %w", err))
	}

	binding, _ := svc.CreateConnectorBinding(ctx, &pluginmgr.CreateConnectorBindingRequest{
		ConnectorInstanceID: instance.ID,
		DeviceID:            deviceID,
		Voucher:             deviceNumber,
	})
	status, _ := svc.GetConnectorInstanceStatus(ctx, instance.ID)
	events, _ := svc.ListConnectorInstanceEvents(ctx, instance.ID, &pluginmgr.ListConnectorEventsRequest{Page: 1, PageSize: 20})

	outRuntime := *runtime
	outRuntime.EnvVars = maskEnvVars(outRuntime.EnvVars)
	out := deployResult{Connector: *connector, Runtime: outRuntime, Instance: *instance, Binding: binding, Status: status, Events: events}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	if err := enc.Encode(out); err != nil {
		fatal(err)
	}
}

func findConnector(ctx context.Context, svc *pluginmgr.Service, key string) (*pluginmgr.DeviceConnector, error) {
	list, err := svc.ListDeviceConnectors(ctx, &pluginmgr.ListDeviceConnectorsRequest{Page: 1, PageSize: 100})
	if err != nil {
		return nil, fmt.Errorf("list device connectors: %w", err)
	}
	for i := range list.List {
		if list.List[i].ConnectorKey == key {
			return &list.List[i], nil
		}
	}
	return nil, nil
}

func ensureXiaomiDevice(ctx context.Context, dsn, deviceID, username, password, did, ip, model string) error {
	db, err := sql.Open("pgx", dsn)
	if err != nil {
		return err
	}
	defer db.Close()

	deviceConfigID := getenv("XIAOMI_DEVICE_CONFIG_ID", "8ab14a5b-95d8-4f54-9f49-3d2d02ad7002")
	additionalInfo := fmt.Sprintf(`{"source":"xiaomi-service","model":%q,"ip":%q,"did":%q}`, model, ip, did)
	voucher := fmt.Sprintf(`{"username":%q,"password":%q}`, username, password)

	if _, err := db.ExecContext(ctx, `
		INSERT INTO device_configs (
			id, name, protocol_type, device_type, protocol_config, description, tenant_id, created_at, updated_at
		) VALUES (
			$1, 'Xiaomi Service Default', 'xiaomi', '1', '{}'::json, 'Created by deploy-xiaomi-service', 'J8gc5ibL', now(), now()
		)
		ON CONFLICT (id) DO UPDATE SET
			protocol_type = EXCLUDED.protocol_type,
			protocol_config = EXCLUDED.protocol_config,
			updated_at = now()
	`, deviceConfigID); err != nil {
		return fmt.Errorf("upsert device_config: %w", err)
	}

	_, err = db.ExecContext(ctx, `
		INSERT INTO devices (
			id, name, voucher, tenant_id, is_enabled, activate_flag,
			created_at, update_at, device_number, additional_info,
			protocol_config, is_online, access_way, description, device_config_id
		) VALUES (
			$1, $2, $3, 'J8gc5ibL', 'enable', 'active',
			now(), now(), $4, $5::json,
			'{}'::json, 1, 'mqtt', 'Bound to Xiaomi service connector', $6
		)
		ON CONFLICT (id) DO UPDATE SET
			name = EXCLUDED.name,
			voucher = EXCLUDED.voucher,
			device_number = EXCLUDED.device_number,
			update_at = now(),
			is_online = 1,
			additional_info = EXCLUDED.additional_info,
			description = EXCLUDED.description,
			device_config_id = EXCLUDED.device_config_id
	`, deviceID, "小米 Yeelight "+ip, voucher, username, additionalInfo, deviceConfigID)
	return err
}

func setDefaultEnv(key, value string) {
	if strings.TrimSpace(os.Getenv(key)) == "" {
		_ = os.Setenv(key, value)
	}
}

func getenv(key, fallback string) string {
	if value := strings.TrimSpace(os.Getenv(key)); value != "" {
		return value
	}
	return fallback
}

func maskEnvVars(values map[string]string) map[string]string {
	masked := make(map[string]string, len(values))
	for key, value := range values {
		upperKey := strings.ToUpper(key)
		if strings.Contains(upperKey, "TOKEN") || strings.Contains(upperKey, "PASS") || strings.Contains(upperKey, "OAUTH") {
			masked[key] = "***"
			continue
		}
		masked[key] = value
	}
	return masked
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, err)
	os.Exit(1)
}
