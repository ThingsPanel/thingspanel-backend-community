package main

import (
	"fmt"
	"os"

	"encore.app/cmd/internal/deployutil"
)

func main() {
	apiKey := os.Getenv("OWM_API_KEY")
	cfg := deployutil.Config{
		ConnectorKey:      "openweathermap",
		DisplayName:       "OpenWeatherMap 天气接入服务",
		MQTTTopicPrefix:   "plugin/openweathermap/",
		DeviceTypeSupport: "gateway",
		Description:       "OpenWeatherMap third-party weather data access service",
		ImageEnv:          "OPENWEATHERMAP_SERVICE_IMAGE",
		DefaultImage:      "openweathermap-service:1.0.0",
		NamespaceEnv:      "OPENWEATHERMAP_SERVICE_NAMESPACE",
		DefaultNamespace:  "connector-instances",
		HTTPPort:          9001,
		HealthCheckPath:   "/health",
		IntegrationKind:   "service_access",
		LegacyServiceType: 2,
		ExtraEnv: map[string]string{
			"OWM_LAT":                        getenv("OWM_LAT", "31.2304"),
			"OWM_LON":                        getenv("OWM_LON", "121.4737"),
			"OWM_CITY":                       getenv("OWM_CITY", "Shanghai"),
			"OWM_UNITS":                      getenv("OWM_UNITS", "metric"),
			"OWM_LANG":                       getenv("OWM_LANG", "zh_cn"),
			"OWM_TELEMETRY_INTERVAL_SECONDS": getenv("OWM_TELEMETRY_INTERVAL_SECONDS", "1800"),
			"OWM_API_KEY":                    apiKey,
		},
	}
	if err := deployutil.Run(cfg); err != nil {
		fatal(err)
	}
}

func getenv(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

func fatal(err error) {
	fmt.Fprintf(os.Stderr, "error: %v\n", err)
	os.Exit(1)
}
