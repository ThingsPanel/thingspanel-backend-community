package telemetry

import (
	"context"
	"time"

	"encore.app/internal/legacy"
)

//encore:service
type Service struct{}

type GetCurrentRequest struct {
	DeviceID string `query:"device_id"`
}

type TelemetryPoint struct {
	Key   string `json:"key"`
	Label string `json:"label"`
	Unit  string `json:"unit"`
	Ts    string `json:"ts"`
	Value string `json:"value"`
}

type GetCurrentResponse struct {
	Code      int              `json:"code"`
	Message   string           `json:"message"`
	RequestID string           `json:"requestId"`
	Data      []TelemetryPoint `json:"data"`
}

// GetCurrent returns device telemetry through Go connector (legacy compatibility layer).
//
//encore:api public method=GET path=/v1/telemetry/current
func (s *Service) GetCurrent(ctx context.Context, req *GetCurrentRequest) (*GetCurrentResponse, error) {
	cli := legacy.NewFromEnv()
	points, err := cli.GetTelemetryCurrent(ctx, req.DeviceID)
	if err != nil {
		return nil, err
	}
	out := make([]TelemetryPoint, 0, len(points))
	for _, p := range points {
		out = append(out, TelemetryPoint{Key: p.Key, Label: p.Label, Unit: p.Unit, Ts: p.Ts, Value: p.Value})
	}
	return &GetCurrentResponse{Code: 200, Message: "ok", RequestID: "", Data: out}, nil
}

type GetHistoryRequest struct {
	DeviceID string `query:"device_id"`
	Key      string `query:"key"`
	Hours    int    `query:"hours"`
	Page     int    `query:"page"`
	PageSize int    `query:"page_size"`
}

type GetHistoryResponse struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"requestId"`
	DeviceID  string `json:"device_id"`
	Key       string `json:"key"`
	Hours     int    `json:"hours"`
	StartTime int64  `json:"start_time"`
	EndTime   int64  `json:"end_time"`
	Raw       string `json:"raw"`
}

// GetHistory proxies telemetry history page endpoint.
//
//encore:api public method=GET path=/v1/telemetry/history
func (s *Service) GetHistory(ctx context.Context, req *GetHistoryRequest) (*GetHistoryResponse, error) {
	hours := req.Hours
	if hours <= 0 {
		hours = 24
	}
	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 {
		pageSize = 20
	}
	endMS := time.Now().UnixMilli()
	startMS := endMS - int64(hours)*3600*1000

	cli := legacy.NewFromEnv()
	raw, err := cli.GetTelemetryHistory(ctx, req.DeviceID, req.Key, startMS, endMS, page, pageSize)
	if err != nil {
		return nil, err
	}
	return &GetHistoryResponse{
		Code:      200,
		Message:   "ok",
		RequestID: "",
		DeviceID:  req.DeviceID,
		Key:       req.Key,
		Hours:     hours,
		StartTime: startMS,
		EndTime:   endMS,
		Raw:       string(raw),
	}, nil
}

type GetControlLogsRequest struct {
	DeviceID string `query:"device_id"`
	Page     int    `query:"page"`
	PageSize int    `query:"page_size"`
}

type GetControlLogsResponse struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"requestId"`
	Raw       string `json:"raw"`
}

// GetControlLogs proxies telemetry set logs endpoint.
//
//encore:api public method=GET path=/v1/telemetry/control-logs
func (s *Service) GetControlLogs(ctx context.Context, req *GetControlLogsRequest) (*GetControlLogsResponse, error) {
	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 {
		pageSize = 20
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.GetTelemetryControlLogs(ctx, req.DeviceID, page, pageSize)
	if err != nil {
		return nil, err
	}
	return &GetControlLogsResponse{Code: 200, Message: "ok", RequestID: "", Raw: string(raw)}, nil
}
