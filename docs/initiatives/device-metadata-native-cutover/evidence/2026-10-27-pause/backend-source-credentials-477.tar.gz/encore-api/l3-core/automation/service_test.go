package automation

import (
	"context"
	"testing"
)

func TestCreateSwitchDeleteRule(t *testing.T) {
	svc := &Service{}
	createResp, err := svc.CreateRule(context.Background(), &CreateRuleRequest{
		Name:         "rule-a",
		TargetDevice: "dev-x",
		TriggerKey:   "switch",
		TriggerValue: "1",
	})
	if err != nil {
		t.Fatalf("CreateRule err: %v", err)
	}
	if createResp.Code != 200 || createResp.Data.ID == "" {
		t.Fatalf("unexpected create: %+v", createResp)
	}

	swResp, err := svc.SwitchRule(context.Background(), &SwitchRuleRequest{ID: createResp.Data.ID, Enabled: false})
	if err != nil {
		t.Fatalf("SwitchRule err: %v", err)
	}
	if swResp.Code != 200 || swResp.Data.Enabled {
		t.Fatalf("unexpected switch: %+v", swResp)
	}

	delResp, err := svc.DeleteRule(context.Background(), &DeleteRuleRequest{ID: createResp.Data.ID})
	if err != nil {
		t.Fatalf("DeleteRule err: %v", err)
	}
	if delResp.Code != 200 || delResp.Data.ID == "" {
		t.Fatalf("unexpected delete: %+v", delResp)
	}
}
