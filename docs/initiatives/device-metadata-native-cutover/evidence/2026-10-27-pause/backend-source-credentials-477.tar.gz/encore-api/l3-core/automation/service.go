package automation

import (
	"context"
	"strings"

	"encore.app/l1-access/authn"
	"encore.app/internal/authz"
	"encore.app/internal/closedloop"
	"fmt"
)

//encore:service
type Service struct{}

type CreateRuleRequest struct {
	Name         string `json:"name"`
	TargetDevice string `json:"target_device_id"`
	TriggerKey   string `json:"trigger_key"`
	TriggerValue string `json:"trigger_value"`
}

type SwitchRuleRequest struct {
	ID      string `json:"id"`
	Enabled bool   `json:"enabled"`
}

type DeleteRuleRequest struct {
	ID string `query:"id"`
}

type ListRuleRequest struct {
	DeviceID string `query:"device_id"`
}

type RuleData struct {
	ID           string `json:"id"`
	Name         string `json:"name"`
	TargetDevice string `json:"target_device_id"`
	TriggerKey   string `json:"trigger_key"`
	TriggerValue string `json:"trigger_value"`
	Enabled      bool   `json:"enabled"`
	CreatedAt    string `json:"created_at"`
}

type RuleEnvelope struct {
	Code      int      `json:"code"`
	Message   string   `json:"message"`
	RequestID string   `json:"requestId"`
	Data      RuleData `json:"data"`
}

type RuleListEnvelope struct {
	Code      int        `json:"code"`
	Message   string     `json:"message"`
	RequestID string     `json:"requestId"`
	Data      []RuleData `json:"data"`
}

func toData(r closedloop.Rule) RuleData {
	return RuleData{
		ID:           r.ID,
		Name:         r.Name,
		TargetDevice: r.TargetDevice,
		TriggerKey:   r.TriggerKey,
		TriggerValue: r.TriggerValue,
		Enabled:      r.Enabled,
		CreatedAt:    r.CreatedAt,
	}
}

//encore:api auth method=POST path=/v1/automations/rules
func (s *Service) CreateRule(ctx context.Context, req *CreateRuleRequest) (*RuleEnvelope, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if req == nil || strings.TrimSpace(req.TargetDevice) == "" {
		return &RuleEnvelope{Code: 400, Message: "target_device_id required", RequestID: "req-automation-create"}, nil
	}
	if !authz.CanDevice(ad, "manage", req.TargetDevice) {
		return nil, fmt.Errorf("no manage permission on device")
	}
	name := strings.TrimSpace(req.Name)
	if name == "" {
		name = "switch-alert"
	}
	triggerKey := strings.TrimSpace(req.TriggerKey)
	if triggerKey == "" {
		triggerKey = "switch"
	}
	triggerValue := strings.TrimSpace(req.TriggerValue)
	if triggerValue == "" {
		triggerValue = "1"
	}
	r := closedloop.CreateRule(name, req.TargetDevice, triggerKey, triggerValue)
	return &RuleEnvelope{Code: 200, Message: "rule created", RequestID: "req-automation-create", Data: toData(r)}, nil
}

//encore:api auth method=POST path=/v1/automations/rules/switch
func (s *Service) SwitchRule(ctx context.Context, req *SwitchRuleRequest) (*RuleEnvelope, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if !authz.Can(ad, "device", "manage") {
		return nil, fmt.Errorf("manage permission required")
	}
	if req == nil || strings.TrimSpace(req.ID) == "" {
		return &RuleEnvelope{Code: 400, Message: "id required", RequestID: "req-automation-switch"}, nil
	}
	r, ok := closedloop.SwitchRule(req.ID, req.Enabled)
	if !ok {
		return &RuleEnvelope{Code: 404, Message: "rule not found", RequestID: "req-automation-switch"}, nil
	}
	return &RuleEnvelope{Code: 200, Message: "rule switched", RequestID: "req-automation-switch", Data: toData(r)}, nil
}

//encore:api auth method=DELETE path=/v1/automations/rules
func (s *Service) DeleteRule(ctx context.Context, req *DeleteRuleRequest) (*RuleEnvelope, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if !authz.Can(ad, "device", "manage") {
		return nil, fmt.Errorf("manage permission required")
	}
	if req == nil || strings.TrimSpace(req.ID) == "" {
		return &RuleEnvelope{Code: 400, Message: "id required", RequestID: "req-automation-delete"}, nil
	}
	r, ok := closedloop.DeleteRule(req.ID)
	if !ok {
		return &RuleEnvelope{Code: 404, Message: "rule not found", RequestID: "req-automation-delete"}, nil
	}
	return &RuleEnvelope{Code: 200, Message: "rule deleted", RequestID: "req-automation-delete", Data: toData(r)}, nil
}

//encore:api auth method=GET path=/v1/automations/rules
func (s *Service) ListRules(ctx context.Context, req *ListRuleRequest) (*RuleListEnvelope, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if !authz.Can(ad, "device", "view") {
		return nil, fmt.Errorf("view permission required")
	}
	deviceID := ""
	if req != nil {
		deviceID = strings.TrimSpace(req.DeviceID)
		if deviceID != "" && !authz.CanDevice(ad, "view", deviceID) {
			return nil, fmt.Errorf("no view permission on device")
		}
	}
	rules := closedloop.ListRules(deviceID)
	out := make([]RuleData, 0, len(rules))
	for _, r := range rules {
		out = append(out, toData(r))
	}
	return &RuleListEnvelope{Code: 200, Message: "ok", RequestID: "req-automation-list", Data: out}, nil
}
