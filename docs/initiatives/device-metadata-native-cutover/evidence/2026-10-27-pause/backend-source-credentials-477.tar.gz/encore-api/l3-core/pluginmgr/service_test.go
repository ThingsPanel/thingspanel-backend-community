package pluginmgr

import (
	"context"
	"testing"
)

type fakeRunner struct {
	calls []runnerCall
}

type runnerCall struct {
	name string
	args []string
}

func (f *fakeRunner) Run(_ context.Context, name string, args ...string) ([]byte, error) {
	cp := make([]string, len(args))
	copy(cp, args)
	f.calls = append(f.calls, runnerCall{name: name, args: cp})
	return []byte("ok"), nil
}

func TestInstallTCPPlugin_DryRunReturnsCommandPlan(t *testing.T) {
	svc := &Service{runner: &fakeRunner{}}

	resp, err := svc.InstallProtocolPlugin(context.Background(), &InstallRequest{
		Host:            "10.0.0.8",
		User:            "root",
		PrivateKeyPath:  "/home/me/.ssh/id_ed25519",
		CertificatePath: "/home/me/.ssh/id_ed25519-cert.pub",
		KnownHostsPath:  "/home/me/.ssh/known_hosts",
		DryRun:          true,
		RepoURL:         "https://github.com/ThingsPanel/thingspanel-adapter-tcp.git",
		Branch:          "main",
		PluginDir:       "/opt/thingspanel/plugins",
	})
	if err != nil {
		t.Fatalf("InstallProtocolPlugin err=%v", err)
	}
	if resp.Code != 200 {
		t.Fatalf("unexpected code=%d", resp.Code)
	}
	if len(resp.Plan) == 0 {
		t.Fatalf("expected non-empty command plan")
	}
	if len(svc.runner.(*fakeRunner).calls) != 0 {
		t.Fatalf("dry-run should not execute commands")
	}
}

func TestInstallTCPPlugin_ApplyInvokesSSHRunner(t *testing.T) {
	fr := &fakeRunner{}
	svc := &Service{runner: fr}

	resp, err := svc.InstallProtocolPlugin(context.Background(), &InstallRequest{
		Host:           "10.0.0.8",
		Port:           2222,
		User:           "root",
		PrivateKeyPath: "/home/me/.ssh/id_ed25519",
		DryRun:         false,
		RepoURL:        "https://github.com/ThingsPanel/thingspanel-adapter-tcp.git",
		Branch:         "main",
		PluginDir:      "/opt/thingspanel/plugins",
		ConfigJSON:     "{\"mode\":\"tcp\"}",
		ConfigPath:     "/etc/thingspanel/plugins/adapter-tcp.json",
		RestartCommand: "systemctl restart thingspanel-backend",
	})
	if err != nil {
		t.Fatalf("InstallProtocolPlugin err=%v", err)
	}
	if resp.Code != 200 {
		t.Fatalf("unexpected code=%d", resp.Code)
	}
	if len(fr.calls) != 3 {
		t.Fatalf("expected 3 ssh calls (install/config/restart), got %d", len(fr.calls))
	}
	if fr.calls[0].name != "ssh" {
		t.Fatalf("expected ssh command, got %s", fr.calls[0].name)
	}
}
