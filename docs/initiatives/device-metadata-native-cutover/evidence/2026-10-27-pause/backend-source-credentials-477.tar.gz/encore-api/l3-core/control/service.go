package control

import (
	"context"
	"strings"

	"encore.app/l1-access/authn"
	"encore.app/internal/authz"
	"encore.app/internal/legacy"
	"fmt"
)

//encore:service
type Service struct{}

type CommandRequest struct {
	DeviceID string `json:"device_id"`
	Identify string `json:"identify"`
	Value    string `json:"value"`
}

type CommandResponse struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"requestId"`
	Data      struct {
		DeviceID string `json:"deviceId"`
		Identify string `json:"identify"`
		Value    string `json:"value"`
	} `json:"data"`
}

// Publish sends command via Go connector to legacy API.
//
//encore:api auth method=POST path=/v1/devices/command
func (s *Service) Publish(ctx context.Context, req *CommandRequest) (*CommandResponse, error) {
	ad := authn.CurrentData()
	if ad == nil {
		return nil, fmt.Errorf("auth required")
	}
	if req == nil || strings.TrimSpace(req.DeviceID) == "" {
		return nil, fmt.Errorf("device_id required")
	}
	if !authz.CanDevice(ad, "control", req.DeviceID) {
		return nil, fmt.Errorf("no control permission on device")
	}

	identify := req.Identify
	if identify == "" {
		identify = "switch"
	}
	cli := legacy.NewFromEnv()
	code, msg, err := cli.PublishCommand(ctx, req.DeviceID, identify, req.Value)
	if err != nil {
		return nil, err
	}
	resp := &CommandResponse{Code: code, Message: msg, RequestID: ""}
	resp.Data.DeviceID = req.DeviceID
	resp.Data.Identify = identify
	resp.Data.Value = req.Value
	return resp, nil
}
