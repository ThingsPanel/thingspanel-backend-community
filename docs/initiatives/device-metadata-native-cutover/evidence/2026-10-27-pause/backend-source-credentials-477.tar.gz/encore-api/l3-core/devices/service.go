package devices

import (
	"context"
	"encoding/json"
	"fmt"
	"strings"

	"encore.app/internal/legacy"
)

//encore:service
type Service struct{}

type DeviceIDRequest struct {
	DeviceID string `query:"device_id"`
}

type DeviceNumberRequest struct {
	DeviceNumber string `query:"device_number"`
}

type ListDevicesRequest struct {
	Page     int `query:"page"`
	PageSize int `query:"page_size"`
}

type SelectorRequest struct {
	Page     int    `query:"page"`
	PageSize int    `query:"page_size"`
	Search   string `query:"search"`
}

type BodyPayloadRequest struct {
	Payload string `json:"payload"`
}

type RawResponse struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"requestId"`
	Raw       string `json:"raw"`
}

func decodePayload(raw string) (any, error) {
	trimmed := strings.TrimSpace(raw)
	if trimmed == "" {
		return nil, fmt.Errorf("payload required")
	}
	var body any
	if err := json.Unmarshal([]byte(trimmed), &body); err != nil {
		return nil, fmt.Errorf("invalid payload json: %w", err)
	}
	return body, nil
}

func rawOK(raw json.RawMessage) *RawResponse {
	return &RawResponse{Code: 200, Message: "ok", RequestID: "", Raw: string(raw)}
}

// GetDetail proxies legacy device detail via Go connector.
//
//encore:api public method=GET path=/v1/devices/detail
func (s *Service) GetDetail(ctx context.Context, req *DeviceIDRequest) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.GetDeviceDetail(ctx, req.DeviceID)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// List proxies paged device list.
//
//encore:api public method=GET path=/v1/devices/list
func (s *Service) List(ctx context.Context, req *ListDevicesRequest) (*RawResponse, error) {
	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 {
		pageSize = 50
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.ListDevices(ctx, page, pageSize)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// ListSimple proxies simple device list.
//
//encore:api public method=GET path=/v1/devices/list-simple
func (s *Service) ListSimple(ctx context.Context) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.ListDevicesSimple(ctx)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// GetOnlineStatus proxies device online status.
//
//encore:api public method=GET path=/v1/devices/online-status
func (s *Service) GetOnlineStatus(ctx context.Context, req *DeviceIDRequest) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.GetDeviceOnlineStatus(ctx, req.DeviceID)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// GetCommandLogs proxies command set logs.
//
//encore:api public method=GET path=/v1/devices/command-logs
func (s *Service) GetCommandLogs(ctx context.Context, req *ListDevicesRequestWithID) (*RawResponse, error) {
	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 {
		pageSize = 20
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.GetCommandLogs(ctx, req.DeviceID, page, pageSize)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

type ListDevicesRequestWithID struct {
	DeviceID string `query:"device_id"`
	Page     int    `query:"page"`
	PageSize int    `query:"page_size"`
}

// GetCommandIdentifiers proxies command identifiers by device.
//
//encore:api public method=GET path=/v1/devices/command-identifiers
func (s *Service) GetCommandIdentifiers(ctx context.Context, req *DeviceIDRequest) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.GetCommandIdentifiers(ctx, req.DeviceID)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// Create proxies device creation.
//
//encore:api public method=POST path=/v1/devices/create
func (s *Service) Create(ctx context.Context, req *BodyPayloadRequest) (*RawResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("payload required")
	}
	body, err := decodePayload(req.Payload)
	if err != nil {
		return nil, err
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.CreateDevice(ctx, body)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// Update proxies device update.
//
//encore:api public method=PUT path=/v1/devices/update
func (s *Service) Update(ctx context.Context, req *BodyPayloadRequest) (*RawResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("payload required")
	}
	body, err := decodePayload(req.Payload)
	if err != nil {
		return nil, err
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.UpdateDevice(ctx, body)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// Delete proxies device deletion.
//
//encore:api public method=DELETE path=/v1/devices/delete
func (s *Service) Delete(ctx context.Context, req *DeviceIDRequest) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.DeleteDevice(ctx, req.DeviceID)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// Activate proxies device activation.
//
//encore:api public method=PUT path=/v1/devices/activate
func (s *Service) Activate(ctx context.Context, req *BodyPayloadRequest) (*RawResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("payload required")
	}
	body, err := decodePayload(req.Payload)
	if err != nil {
		return nil, err
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.ActivateDevice(ctx, body)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// CheckNumber proxies device number check.
//
//encore:api public method=GET path=/v1/devices/check-number
func (s *Service) CheckNumber(ctx context.Context, req *DeviceNumberRequest) (*RawResponse, error) {
	cli := legacy.NewFromEnv()
	raw, err := cli.CheckDeviceNumber(ctx, req.DeviceNumber)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// Selector proxies device selector.
//
//encore:api public method=GET path=/v1/devices/selector
func (s *Service) Selector(ctx context.Context, req *SelectorRequest) (*RawResponse, error) {
	page := req.Page
	if page <= 0 {
		page = 1
	}
	pageSize := req.PageSize
	if pageSize <= 0 {
		pageSize = 50
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.DeviceSelector(ctx, page, pageSize, req.Search)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}

// UpdateVoucher proxies voucher update.
//
//encore:api public method=POST path=/v1/devices/update-voucher
func (s *Service) UpdateVoucher(ctx context.Context, req *BodyPayloadRequest) (*RawResponse, error) {
	if req == nil {
		return nil, fmt.Errorf("payload required")
	}
	body, err := decodePayload(req.Payload)
	if err != nil {
		return nil, err
	}
	cli := legacy.NewFromEnv()
	raw, err := cli.UpdateDeviceVoucher(ctx, body)
	if err != nil {
		return nil, err
	}
	return rawOK(raw), nil
}
