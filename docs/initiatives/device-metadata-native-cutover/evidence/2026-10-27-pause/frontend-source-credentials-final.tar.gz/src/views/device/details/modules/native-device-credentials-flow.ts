import type { CreateDeviceCredential } from '@/service/api/device-credentials-native'

export interface NativeCredentialCreateAttempt {
  deviceId: string
  payload: CreateDeviceCredential
  key: string
  previouslyUnknown: boolean
}

export function createNativeCredentialAttempt(
  deviceId: string,
  payload: CreateDeviceCredential,
  key: string
): NativeCredentialCreateAttempt {
  return { deviceId, payload: { ...payload }, key, previouslyUnknown: false }
}

export function shouldRetainNativeCredentialAttempt(
  status: number | undefined,
  outcomeUnknown: boolean,
  previouslyUnknown: boolean
): boolean {
  return outcomeUnknown || previouslyUnknown || status !== 422
}

export async function createNativeCredentialAndRefresh<T>(
  attempt: NativeCredentialCreateAttempt,
  // eslint-disable-next-line no-unused-vars
  create: (deviceId: string, payload: CreateDeviceCredential, key: string) => Promise<T>,
  // eslint-disable-next-line no-unused-vars
  acceptCreated: (result: T) => void,
  // eslint-disable-next-line no-unused-vars
  refreshSummaries: (deviceId: string) => Promise<void>
): Promise<{ result: T; refreshFailed: boolean }> {
  const result = await create(attempt.deviceId, attempt.payload, attempt.key)
  acceptCreated(result)
  try {
    await refreshSummaries(attempt.deviceId)
    return { result, refreshFailed: false }
  } catch {
    return { result, refreshFailed: true }
  }
}
