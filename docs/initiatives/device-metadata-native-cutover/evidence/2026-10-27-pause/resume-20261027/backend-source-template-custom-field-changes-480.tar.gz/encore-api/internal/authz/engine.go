package authz

import (
	"sync"

	"encore.app/l1-access/authn"
	"github.com/casbin/casbin/v2"
	"github.com/casbin/casbin/v2/model"
)

var (
	once     sync.Once
	enforcer *casbin.Enforcer
	initErr  error
)

func getEnforcer() (*casbin.Enforcer, error) {
	once.Do(func() {
		mconf := `
[request_definition]
r = sub, obj, act

[policy_definition]
p = sub, obj, act

[role_definition]
g = _, _

[policy_effect]
e = some(where (p.eft == allow))

[matchers]
m = g(r.sub, p.sub) && (p.obj == "*" || r.obj == p.obj) && (p.act == "*" || r.act == p.act)
`
		m, err := model.NewModelFromString(mconf)
		if err != nil {
			initErr = err
			return
		}
		e, err := casbin.NewEnforcer(m)
		if err != nil {
			initErr = err
			return
		}
		// Role -> permission mappings.
		// sub(role), obj(resource), act(action)
		_, _ = e.AddPolicy("platform_admin", "*", "*")
		_, _ = e.AddPolicy("tenant_admin", "device", "view")
		_, _ = e.AddPolicy("tenant_admin", "device", "control")
		_, _ = e.AddPolicy("tenant_admin", "device", "manage")
		_, _ = e.AddPolicy("tenant_admin", "plugin", "manage")
		// Native device-metadata group access is granted only to the verified
		// Community TENANT_ADMIN identity. Scopes are not consulted here: the
		// current Community user-token issuer does not mint delegated scopes.
		_, _ = e.AddPolicy("TENANT_ADMIN", "group", "read")
		_, _ = e.AddPolicy("TENANT_ADMIN", "group", "write")
		_, _ = e.AddPolicy("TENANT_ADMIN", "group", "delete")
		_, _ = e.AddPolicy("TENANT_ADMIN", "device", "read")
		_, _ = e.AddPolicy("TENANT_ADMIN", "device", "write")
		_, _ = e.AddPolicy("TENANT_ADMIN", "device", "credentials:read")
		_, _ = e.AddPolicy("TENANT_ADMIN", "device", "credentials:write")
		_, _ = e.AddPolicy("TENANT_ADMIN", "template", "read")
		_, _ = e.AddPolicy("TENANT_ADMIN", "template", "write")
		// Global immutable release publication is a private platform operation;
		// this grants no tenant resource access or delegated tenant identity.
		_, _ = e.AddPolicy("SYS_ADMIN", "provider", "publish")
		_, _ = e.AddPolicy("tenant_operator", "device", "view")
		_, _ = e.AddPolicy("tenant_operator", "device", "control")
		_, _ = e.AddPolicy("tenant_viewer", "device", "view")
		enforcer = e
	})
	return enforcer, initErr
}

func Can(data *authn.Data, resource, action string) bool {
	if data == nil || len(data.Roles) == 0 {
		return false
	}
	e, err := getEnforcer()
	if err != nil {
		return false
	}
	for _, role := range data.Roles {
		ok, _ := e.Enforce(role, resource, action)
		if ok {
			return true
		}
	}
	return false
}

func CanDevice(data *authn.Data, action, deviceID string) bool {
	if !Can(data, "device", action) {
		return false
	}
	if hasRole(data.Roles, "platform_admin") {
		return true
	}
	// Empty binding list means tenant-level role scope.
	if len(data.AuthorizedDeviceIDs) == 0 {
		return true
	}
	for _, d := range data.AuthorizedDeviceIDs {
		if d == deviceID {
			return true
		}
	}
	return false
}

func hasRole(roles []string, target string) bool {
	for _, r := range roles {
		if r == target {
			return true
		}
	}
	return false
}
