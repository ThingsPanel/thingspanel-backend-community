export interface DeviceGroupDeleteIntent {
  groupId: string
  etag: string
  key: string
  outcomeUnknown: boolean
}

const intents = new Map<string, DeviceGroupDeleteIntent>()
const inFlight = new Set<string>()

export function beginDeviceGroupDelete(groupId: string): boolean {
  if (inFlight.has(groupId)) return false
  inFlight.add(groupId)
  return true
}

export function finishDeviceGroupDelete(groupId: string): void {
  inFlight.delete(groupId)
}

export function getDeviceGroupDeleteIntent(groupId: string): DeviceGroupDeleteIntent | undefined {
  return intents.get(groupId)
}

export function listDeviceGroupDeleteIntents(): DeviceGroupDeleteIntent[] {
  return [...intents.values()]
}

export function createDeviceGroupDeleteIntent(groupId: string, etag: string, key: string): DeviceGroupDeleteIntent {
  const intent = { groupId, etag, key, outcomeUnknown: false }
  intents.set(groupId, intent)
  return intent
}

export async function prepareDeviceGroupDeleteIntent(
  groupId: string,
  readEtag: () => Promise<string>,
  createKey: () => string
): Promise<DeviceGroupDeleteIntent> {
  const existing = intents.get(groupId)
  if (existing) return existing
  return createDeviceGroupDeleteIntent(groupId, await readEtag(), createKey())
}

export function completeDeviceGroupDelete(groupId: string): void {
  intents.delete(groupId)
}

/** Explicit first-attempt conflicts are safe to discard; after uncertainty every retry keeps the receipt identity. */
export function failDeviceGroupDelete(
  groupId: string,
  status?: number
): { retained: boolean; intent?: DeviceGroupDeleteIntent } {
  const intent = intents.get(groupId)
  if (!intent) return { retained: false }
  if ((status === 409 || status === 412) && !intent.outcomeUnknown) {
    intents.delete(groupId)
    return { retained: false }
  }
  intent.outcomeUnknown = true
  return { retained: true, intent }
}

export function deviceGroupDeleteErrorStatus(error: unknown): number | undefined {
  const candidate = error as { status?: unknown } | null
  return typeof candidate?.status === 'number' ? candidate.status : undefined
}
