import assert from 'node:assert/strict'
import test from 'node:test'
import {
  beginDeviceGroupDelete,
  completeDeviceGroupDelete,
  createDeviceGroupDeleteIntent,
  failDeviceGroupDelete,
  finishDeviceGroupDelete,
  getDeviceGroupDeleteIntent,
  prepareDeviceGroupDeleteIntent
} from './device-group-delete-state'

test('unknown delete keeps the original ETag and key through later authorization or conflict errors', () => {
  createDeviceGroupDeleteIntent('group-a', '"v7"', 'delete-key-0001')
  assert.equal(failDeviceGroupDelete('group-a').retained, true)
  assert.equal(failDeviceGroupDelete('group-a', 401).retained, true)
  assert.equal(failDeviceGroupDelete('group-a', 409).retained, true)
  assert.deepEqual(getDeviceGroupDeleteIntent('group-a'), {
    groupId: 'group-a',
    etag: '"v7"',
    key: 'delete-key-0001',
    outcomeUnknown: true
  })
})

test('unknown retry reuses the intent without reading an ETag for an already-deleted group', async () => {
  createDeviceGroupDeleteIntent('group-a-retry', '"v9"', 'delete-key-0004')
  failDeviceGroupDelete('group-a-retry')
  let getCount = 0
  const retry = await prepareDeviceGroupDeleteIntent(
    'group-a-retry',
    async () => {
      getCount += 1
      throw new Error('group may already return 404')
    },
    () => 'incorrect-new-key'
  )
  assert.equal(getCount, 0)
  assert.equal(retry.etag, '"v9"')
  assert.equal(retry.key, 'delete-key-0004')
})

test('first explicit conflict clears intent and one group cannot delete concurrently', () => {
  createDeviceGroupDeleteIntent('group-b', '"v2"', 'delete-key-0002')
  assert.equal(failDeviceGroupDelete('group-b', 412).retained, false)
  assert.equal(getDeviceGroupDeleteIntent('group-b'), undefined)
  assert.equal(beginDeviceGroupDelete('group-b'), true)
  assert.equal(beginDeviceGroupDelete('group-b'), false)
  finishDeviceGroupDelete('group-b')
  assert.equal(beginDeviceGroupDelete('group-b'), true)
  finishDeviceGroupDelete('group-b')
})

test('confirmed delete clears its intent before any later list refresh', () => {
  createDeviceGroupDeleteIntent('group-c', '"v1"', 'delete-key-0003')
  completeDeviceGroupDelete('group-c')
  assert.equal(getDeviceGroupDeleteIntent('group-c'), undefined)
})
